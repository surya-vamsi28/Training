package com.learning.entity;

public enum EROLE {
	ROLE_ADMIN, ROLE_USER
}
