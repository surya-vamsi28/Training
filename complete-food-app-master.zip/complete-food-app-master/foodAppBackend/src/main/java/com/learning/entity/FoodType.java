package com.learning.entity;

public enum FoodType {
	Indian, Chinese, Mexican
}
