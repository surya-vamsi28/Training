package com.learning.exceptions;

@SuppressWarnings("serial")
public class IdNotFoundException extends Exception {
	public IdNotFoundException(String message) {
		super(message);
	}

}
