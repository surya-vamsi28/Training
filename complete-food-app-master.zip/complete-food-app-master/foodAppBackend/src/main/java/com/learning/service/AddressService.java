package com.learning.service;

import com.learning.entity.Address;

public interface AddressService {

	Address addAddress(Address address);

}
