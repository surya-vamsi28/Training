package com.zee.zee5app.service;
import com.zee.zee5app.dto.Register;
import com.zee.zee5app.repository.UserRepository;

// can we do this with 1 object?
// to solve this, they created singleton design pattern

public class UserService2 {
//	private UserRepository repository = UserRepository.getInstance();
	// service is consuming the repository
	private UserService2() 	{ }
	static UserService2 service = null;
	// if we want to create that single object, create in same class
	// and share ref with others by declaring a method
	public static UserService2 getInstance()	{
		// object independent if static. else, dependent on the obj for execution
		if (service == null)
			service = new UserService2();
		// this would be a local ref
		return service;
	}
//	public String addUser(Register register)	{
//		return this.repository.addUser(register);
//	}
//	public Register getUserById(String id)	{
//		return this.repository.getUserById(id);
//	}
//	public Register[] getUsers()	{
//		return this.repository.getUsers();
//	}
//	public String updateUser(String id, String firstName, String lastName, String email, String password)	{
//		return this.repository.updateUser(id, firstName, lastName, email, password);
//	}
//	public String deleteUser(String id)	{
//		return this.repository.deleteUser(id);
//	}
}
