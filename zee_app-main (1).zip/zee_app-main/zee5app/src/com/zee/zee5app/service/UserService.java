package com.zee.zee5app.service;
import java.util.List;
import java.util.Optional;

import com.zee.zee5app.dto.Register;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.repository.UserRepository;

// can we do this with 1 object?
// to solve this, they created singleton design pattern

public interface UserService {
	public String addUser(Register register);
	public Optional<Register> getUserById(String id) throws IdNotFoundException;
	public Register[] getAllUsers();
	public String updateUser(String id, Register register) throws IdNotFoundException;
	public String deleteUserById(String id) throws IdNotFoundException;
	public List<Register> getAllUserDetails();
}
