package com.zee.zee5app.service;
import java.util.Set;

import com.zee.zee5app.dto.*;
import com.zee.zee5app.exception.IdNotFoundException;

public interface MovieService {
    public String addMovie(Movie register);
    public Set<Movie> getMovies();
    public Movie getMovieById(String id) throws IdNotFoundException;
    public String modifyMovie(String id, Movie movie);
    public String deleteMovie(String id);
}