package com.zee.zee5app.service;
import java.util.Set;

import com.zee.zee5app.dto.*;
import com.zee.zee5app.exception.IdNotFoundException;

public interface SubscriptionService {
	public String addSubscription(Subscription register);
	public Subscription getSubscriptionById(String id) throws IdNotFoundException;
	public Set<Subscription> getSubscriptions();
	public String modifySubscription(String id, Subscription subscription);
	public String deleteSubscription(String id);
}