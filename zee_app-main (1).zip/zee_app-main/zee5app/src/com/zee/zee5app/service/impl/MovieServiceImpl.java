package com.zee.zee5app.service.impl;
import java.util.Set;

import com.zee.zee5app.dto.*;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.repository.*;
import com.zee.zee5app.repository.impl.MovieRepositoryImpl;
import com.zee.zee5app.service.MovieService;


public class MovieServiceImpl implements MovieService {
	private MovieRepository repository = MovieRepositoryImpl.getInstance();
	private MovieServiceImpl() 	{ }
	static MovieService service = null;
	public static MovieService getInstance()	{
		if (service == null)
			service = new MovieServiceImpl();
		return service;
	}
    @Override
	public String addMovie(Movie register)	{
		return this.repository.addMovie(register);
	}
    @Override
	public Set<Movie> getMovies()	{
		return this.repository.getMovies();
	}
    @Override
	public Movie getMovieById(String id) throws IdNotFoundException	{
		return this.repository.getMovieById(id);
	}
    @Override
	public String modifyMovie(String id, Movie movie)	{
		return this.repository.modifyMovie(id, movie);
	}
    @Override
	public String deleteMovie(String id)	{
		return this.repository.deleteMovie(id);
	}
}

