package com.zee.zee5app.service.impl;

import java.util.Set;

import com.zee.zee5app.dto.Subscription;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.repository.SubscriptionRepository;
import com.zee.zee5app.repository.impl.SubscriptionRepositoryImpl;
import com.zee.zee5app.service.SubscriptionService;

public class SubscriptionServiceImpl implements SubscriptionService {
	public SubscriptionServiceImpl() 	{ }
	static SubscriptionService service = null;
	
	public static SubscriptionService getInstance()	{
		if (service == null)
			service = new SubscriptionServiceImpl();
		return service;
	}
	
	public SubscriptionRepository repository = SubscriptionRepositoryImpl.getInstance();
	
	@Override
	public String addSubscription(Subscription register)	{
		return repository.addSubscription(register);
	}
	
	@Override
	public Subscription getSubscriptionById(String id) throws IdNotFoundException	{
		return repository.getSubscriptionById(id);
	}
	
	@Override
	public Set<Subscription> getSubscriptions()	{
		return repository.getSubscriptions();
	}
	@Override
	public String modifySubscription(String id, Subscription subscription)	{
		return repository.modifySubscription(id, subscription);
	}
	@Override
	public String deleteSubscription(String id)	{
		return repository.deleteSubscription(id);
	}
}