package com.zee.zee5app.service.impl;
import java.util.Set;

import com.zee.zee5app.dto.*;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.repository.*;
import com.zee.zee5app.repository.impl.SeriesRepositoryImpl;
import com.zee.zee5app.service.SeriesService;


public class SeriesServiceImpl implements SeriesService {
	private SeriesRepository repository = SeriesRepositoryImpl.getInstance();
	private SeriesServiceImpl() 	{ }
	static SeriesService service = null;
	public static SeriesService getInstance()	{
		if (service == null)
			service = new SeriesServiceImpl();
		return service;
	}
	@Override
	public String addSeries(Series register)	{
		return this.repository.addSeries(register);
	}
	@Override
	public Set<Series> getSeries()	{
		return this.repository.getSeries();
	}
	@Override
	public Series getSeriesById(String id) throws IdNotFoundException	{
		return this.repository.getSeriesById(id);
	}
	@Override
	public String modifySeries(String id, Series series)	{
		return this.repository.modifySeries(id, series);
	}
	@Override
	public String deleteSeries(String id)	{
		return this.repository.deleteSeries(id);
	}
}
