package com.zee.zee5app.dto;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidNameException;

import lombok.*;

@Data
@ToString
public class Series {
	private String id;
	private String seriesName;
	private String category;
	private String releaseDate;
	private String trailerLink;
	private int ageLimit;
	private int contentLength;  // in minutes
	private int numEpisodes;
	private int[] episodeLengths;
	private String language;
	private String[] cast;

	public Series() {
		super();
	}
	public Series(String id, String seriesName, String category, String releaseDate,
			String trailerLink, int ageLimit, int contentLength,
			int numEpisodes, int[] episodeLengths, String language,
			String[] cast) {
		super();
		try {
			this.setId(id);
			this.setSeriesName(seriesName);
			this.setCategory(category);
			this.setReleaseDate(releaseDate);
			this.setTrailerLink(trailerLink);
			this.setAgeLimit(ageLimit);
			this.setContentLength(contentLength);
			this.setNumEpisodes(numEpisodes);
			this.setEpisodeLengths(episodeLengths);
			this.setLanguage(language);
			this.setCast(cast);
		} catch (InvalidIdLengthException e) {
			System.out.println("Invalid length");
		} catch (InvalidNameException e) {
			System.out.println("Invalid name");
		}
	}
	
	public void setId(String id) throws InvalidIdLengthException {
		if (id.length() < 3)
			throw new InvalidIdLengthException("Id length is less than 3");
		this.id = id;
	}

	public void setSeriesName(String seriesName) throws InvalidNameException {
		if (seriesName == null || seriesName.length() < 2)
			throw new InvalidNameException("Name length is less than 2");
		this.seriesName = seriesName;
	}
}
