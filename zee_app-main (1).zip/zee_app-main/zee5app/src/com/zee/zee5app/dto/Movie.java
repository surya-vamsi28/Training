package com.zee.zee5app.dto;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidNameException;

import lombok.*;

@Data
@ToString
public class Movie {
	@Setter(value = AccessLevel.NONE)
	private String id;
	@Setter(value = AccessLevel.NONE)
	private String movieName;
	private String category;
	private String releaseDate;
	private String trailerLink;
	private int ageLimit;
	private int contentLength;  // in minutes
	private String language;
	private String[] cast;

	public Movie() {
		super();
	}
	public Movie(String id, String movieName, String category, String releaseDate,
			String trailerLink, int ageLimit, int contentLength,
			String language, String[] cast) {
		super();
		try {
			this.setId(id);
			this.setMovieName(movieName);
			this.setCategory(category);
			this.setReleaseDate(releaseDate);
			this.setTrailerLink(trailerLink);
			this.setAgeLimit(ageLimit);
			this.setContentLength(contentLength);
			this.setLanguage(language);
			this.setCast(cast);
		} catch (InvalidIdLengthException e) {
			System.out.println("Invalid ID length");
		} catch (InvalidNameException e) {
			System.out.println("Invalid Name length");
		}
	}
	
	public void setId(String id) throws InvalidIdLengthException {
		if (id.length() < 3)
			throw new InvalidIdLengthException("Id length is less than 3");
		this.id = id;
	}

	public void setMovieName(String movieName) throws InvalidNameException {
		if (movieName == null || movieName.length() < 2)
			throw new InvalidNameException("Name length is less than 2");
		this.movieName = movieName;
	}
}
