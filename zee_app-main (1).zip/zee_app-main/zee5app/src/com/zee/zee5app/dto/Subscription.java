package com.zee.zee5app.dto;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidNameException;

import lombok.*;

@Data
@ToString
public class Subscription {
	private String id;
	private String dateOfPurchase;
	private boolean status;
	private String packCountry;
	private String paymentMode;
	private boolean autoRenewal;
	private int packDuration;
	private String expiryDate;

	public Subscription() {
		super();
	}
	public Subscription(String id, String dateOfPurchase, boolean status, String packCountry, String paymentMode,
			boolean autoRenewal, int packDuration, String expiryDate) {
		super();
		try {
			this.setId(id);
			this.setDateOfPurchase(dateOfPurchase);
			this.setStatus(status);
			this.setPackCountry(packCountry);
			this.setPaymentMode(paymentMode);
			this.setAutoRenewal(autoRenewal);
			this.setPackDuration(packDuration);
			this.setExpiryDate(expiryDate);
		} catch (InvalidIdLengthException e) {
			System.out.println("Invalid ID length");
		}
	}

	public void setId(String id) throws InvalidIdLengthException {
		if (id.length() < 3)
			throw new InvalidIdLengthException("Id length is less than 3");
		this.id = id;
	}
}
