package com.zee.zee5app.dto;
import lombok.Data;

@Data
public class Login {
	private String userName;
	private String password;
}
