package com.zee.zee5app.repository;
import java.util.Set;

import com.zee.zee5app.dto.*;
import com.zee.zee5app.exception.IdNotFoundException;

public interface SeriesRepository {
	public String addSeries(Series series);
	public Set<Series> getSeries();
	public Series getSeriesById(String id) throws IdNotFoundException;
	public String modifySeries(String id, Series series);
	public String deleteSeries(String id);
}

