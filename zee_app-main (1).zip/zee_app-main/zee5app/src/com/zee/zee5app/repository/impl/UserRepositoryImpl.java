package com.zee.zee5app.repository.impl;

import java.text.CollationElementIterator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import com.zee.zee5app.dto.Register;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.exception.InvalidEmailException;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidNameException;
import com.zee.zee5app.exception.InvalidPasswordException;
import com.zee.zee5app.repository.*;

public class UserRepositoryImpl implements UserRepository {
	private Set<Register> registers = new HashSet<Register>();
	private UserRepositoryImpl()	{ }
	
	private static UserRepository userRepository;
	public static UserRepository getInstance()	{
		if (userRepository == null)
			userRepository = new UserRepositoryImpl();
		return userRepository;
	}

	@Override
	public Register[] getAllUsers()	{
		Register[] registerArray = new Register[registers.size()];
		return registers.toArray(registerArray);
		// return registers;
	}
	
	@Override
	public List<Register> getAllUserDetails()	{
		// Collections.sort(registers);
		// return registers;
		return new ArrayList<Register>(registers);
	}

	@Override
	public Optional<Register> getUserById(String id) throws IdNotFoundException {
		Register register2 = null;
		for (Register register: registers)
			if (register.getId().equals(id))
				return Optional.of(register);
				/* register2 = register;
				break; */
		return Optional.of(Optional.ofNullable(register2).orElseThrow(
					() -> new IdNotFoundException("ID not found")
				));
		/* throw new IdNotFoundException("ID not found");
		return Optional.of(register2);
		if (register2 == null)
			throw new IdNotFoundException("ID not found");
		else
			return register2; */
	}

	@Override
	public String updateUser(String id, Register newRegister) throws IdNotFoundException	{
		for (Register register : registers)
			if (register != null && register.getId().equals(id)) {
				System.out.println("Updating");
				try {
					register.setFirstName(newRegister.getFirstName());
					register.setLastName(newRegister.getLastName());
					register.setEmail(newRegister.getEmail());
					register.setPassword(newRegister.getPassword());
				} catch (InvalidNameException e) {
					e.printStackTrace();
				} catch (InvalidEmailException e) {
					e.printStackTrace();
				} catch (InvalidPasswordException e) {
					e.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				}
				return "Updated successfully";
				/* try {
					// registers.set(i, register);
					registers.get(i).setFirstName(register.getFirstName());
					registers.get(i).setLastName(register.getLastName());
					registers.get(i).setEmail(register.getEmail());
					registers.get(i).setPassword(register.getPassword());
				} catch (InvalidNameException e) {
					e.printStackTrace();
				} catch (InvalidEmailException e) {
					e.printStackTrace();
				} catch (InvalidPasswordException e) {
					e.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				} */
			}
		throw new IdNotFoundException("ID is not found. Can't update");
	}

	@Override
	public String deleteUserById(String id) throws IdNotFoundException	{
		Optional<Register> optional = this.getUserById(id);
		if (optional.isPresent()) {
			// boolean isDeleted = registers.remove(optional.get());
			registers.remove(optional.get());
			System.out.println("Set: " + registers.toString());
//			if (isDeleted)
//				return "Deleted successfully";
//			else
				return "Deletion failed";
		} else
			throw new IdNotFoundException("ID is not found. Can't delete.");
		/* for (int i=0; i<registers.size(); i++)
			if (registers.get(i) != null && registers.get(i).getId().equals(id)) {
				System.out.println("Deleting at position: " + i);
				// shift Left after deleted position
				if (i+1 < registers.size())
					for (int pos=i; pos<registers.size()-1; pos++)
						registers.set(pos, registers.get(pos+1));
				registers.remove(i);
				return "Deleted successfully";
			} */
	}
	
	@Override
	public String addUser(Register register)	{
		boolean isAdded = registers.add(register);
		if (isAdded)
			return "Success";
		else
			return "Failed";
		
		/* // registers.size()  -> shows availability
		// we are expecting occupancy. we use count = 0 at start
		// we shld dynamically grow array size
		if (count == registers.length) { // count is same as array capacity, array is full
			Register[] temp = new Register[registers.length*2];  // new arr of *2 size
			// source, srcPos, dstn, dstnPos, length
			System.arraycopy(registers, 0, temp, 0, registers.length);
			registers = temp;
		}
		count++;
		// validate each field and raise exception if invalid */
	}
}
