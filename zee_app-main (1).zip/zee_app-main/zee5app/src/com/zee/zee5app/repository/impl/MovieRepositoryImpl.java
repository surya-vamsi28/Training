package com.zee.zee5app.repository.impl;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.zee.zee5app.dto.Movie;
import com.zee.zee5app.dto.Series;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidNameException;
import com.zee.zee5app.repository.MovieRepository;

public class MovieRepositoryImpl implements MovieRepository {
	static MovieRepository movieRepository = null;
	private Set<Movie> movies = new TreeSet<>();
	public static MovieRepository getInstance() {
		if (movieRepository == null)
			movieRepository = new MovieRepositoryImpl();
		return movieRepository;
	}

	@Override
	public String addMovie(Movie movie) {
		if (movies.add(movie))
			return "Success";
		else
			return "Failed";
	}

	@Override
	public Set<Movie> getMovies() {
		return movies;
	}

	@Override
	public Movie getMovieById(String id) throws IdNotFoundException {
		for (Movie movie: movies)  // traverse using foreach loop
			if (movie != null && movie.getId().equals(id))
				return movie;
		throw new IdNotFoundException("ID not found");
	}

	@Override
	public String modifyMovie(String id, Movie movie) {
		for (Movie mov: movies) // traverse using foreach loop
			if (mov != null && mov.getId().equals(id)) {
				System.out.println("Updating");
				try {
					mov.setId(movie.getId());
					mov.setMovieName(movie.getMovieName());
					mov.setCategory(movie.getCategory());
					mov.setReleaseDate(movie.getReleaseDate());
					mov.setTrailerLink(movie.getTrailerLink());
					mov.setAgeLimit(movie.getAgeLimit());
					mov.setContentLength(movie.getContentLength());
					mov.setLanguage(movie.getLanguage());
					mov.setCast(movie.getCast());
				} catch (InvalidIdLengthException e) {
					System.out.println("Invalid ID length");
				} catch (InvalidNameException e) {
					System.out.println("Invalid Name length");
				}
				return "Updated successfully";
			}
		return "Movie ID not found";
	}

	@Override
	public String deleteMovie(String id) {
		for (Movie movie: movies)
			if (movie != null && movie.getId().equals(id)) {
				// if (movies.remove(movie))
					return "Deleted successfully";
				// else
					// return "Deletion failed";
			}
		return "Movie ID not found";
	}
}
