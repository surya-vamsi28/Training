package com.zee.zee5app.repository;
import com.zee.zee5app.dto.Register;
import com.zee.zee5app.exception.InvalidEmailException;
import com.zee.zee5app.exception.InvalidNameException;
import com.zee.zee5app.exception.InvalidPasswordException;

// repo. objects are used to call only repo. methods
public class UserRepository2 {
	private Register[] registers = new Register[10];
	private static int count = 0;
	private UserRepository2()	{ }
	
	public Register[] getUsers()	{
		return registers;
		// Register[] temp = new Register[count];
		// System.arraycopy(registers, 0, temp, 0, count);
		// return temp;
	}
	
	public Register getUserById(String id)	{
		for (Register register: registers)  // traverse the arr using foreach loop
			if (register != null && register.getId().equals(id))
				return register;
		return null;
	}
	
	public String updateUser(String id, String firstName, String lastName, String email, String password)	{
		for (int i=0; i<registers.length; i++)
			if (registers[i] != null && registers[i].getId().equals(id)) {
				System.out.println("Updating at position: " + i);
				try {
					registers[i].setFirstName(firstName);
					registers[i].setLastName(lastName);
					registers[i].setEmail(email);
					registers[i].setPassword(password);
				} catch (InvalidNameException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvalidPasswordException e) {
					e.printStackTrace();
				} catch (InvalidEmailException e) {
					e.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				}
				return "Updated successfully";
			}
		return "User ID not found";
	}
	
	public String deleteUser(String id)	{
		for (int i=0; i<registers.length; i++)
			if (registers[i] != null && registers[i].getId().equals(id)) {
				System.out.println("Deleting at position: " + i);
				
				// shift Left after deleted position
				if (i+1 < registers.length)
					for (int pos=i; pos<registers.length-1; pos++)
						registers[pos] = registers[pos+1];
				return "Deleted successfully";
			}
		return "User ID not found";
	}
	
	// add a new user
	public String addUser(Register register)	{
		// registers.length  -> shows availability
		// we are expecting occupancy. we use count = 0 at start
		// we shld dynamically grow array size
		if (count == registers.length) { // count is same as array capacity, array is full
			Register[] temp = new Register[registers.length*2];  // new arr of *2 size
			// source, srcPos, dstn, dstnPos, length
			System.arraycopy(registers, 0, temp, 0, registers.length);
			registers = temp;
		}
		registers[count++] = register;
		return "Success";
	}
	private static UserRepository2 userRepository;
	public static UserRepository2 getInstance()	{
		if (userRepository == null)
			userRepository = new UserRepository2();
		return userRepository;
	}
}
