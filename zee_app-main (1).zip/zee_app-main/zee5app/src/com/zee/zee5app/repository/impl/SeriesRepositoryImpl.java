package com.zee.zee5app.repository.impl;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.zee.zee5app.dto.*;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidNameException;
import com.zee.zee5app.repository.SeriesRepository;

public class SeriesRepositoryImpl implements SeriesRepository {
	private static SeriesRepository seriesRepository = null;
	private SeriesRepositoryImpl() { }
	private Set<Series> series = new TreeSet<>();
	public static SeriesRepository getInstance() {
		if (seriesRepository == null)
			seriesRepository = new SeriesRepositoryImpl();
		return seriesRepository;
	}
    @Override
	public String addSeries(Series ser) {
		if (series.add(ser))
			return "Success";
		else
			return "Failed";
	}
    @Override
	public Set<Series> getSeries() {
		return series;
	}
    @Override
	public Series getSeriesById(String id) throws IdNotFoundException {
		for (Series series: this.series)  // traverse the arr using foreach loop
			if (series != null && series.getId().equals(id))
				return series;
		throw new IdNotFoundException("ID not found");
	}
    @Override
	public String modifySeries(String id, Series series) {
		for (Series ser: this.series)
			if (ser != null && ser.getId().equals(id)) {
				System.out.println("Updating");
				try {
					ser.setId(series.getId());
					ser.setSeriesName(series.getSeriesName());
					ser.setCategory(series.getCategory());
					ser.setReleaseDate(series.getReleaseDate());
					ser.setTrailerLink(series.getTrailerLink());
					ser.setAgeLimit(series.getAgeLimit());
					ser.setContentLength(series.getContentLength());
					ser.setNumEpisodes(series.getNumEpisodes());
					ser.setEpisodeLengths(series.getEpisodeLengths());
					ser.setLanguage(series.getLanguage());
					ser.setCast(series.getCast());
				} catch (InvalidIdLengthException e) {
					System.out.println("Invalid ID length");
				} catch (InvalidNameException e) {
					System.out.println("Invalid Name length");
				}
				return "Updated successfully";
			}
		return "Series ID not found";
	}
    @Override
	public String deleteSeries(String id) {
		for (Series ser: this.series)
			if (ser != null && ser.getId().equals(id)) {
				// if (this.series.remove(ser))
					return "Deleted successfully";
				// else
					// return "Failed";
			}
		return "Series ID not found";
	}
}

