package com.zee.zee5app.repository;
import java.util.Set;

import com.zee.zee5app.dto.*;
import com.zee.zee5app.exception.IdNotFoundException;

public interface SubscriptionRepository {
	public String addSubscription(Subscription subscription);
	public Set<Subscription> getSubscriptions();
	String modifySubscription(String id, Subscription subscription);
	public Subscription getSubscriptionById(String id) throws IdNotFoundException;
	public String deleteSubscription(String id);
}