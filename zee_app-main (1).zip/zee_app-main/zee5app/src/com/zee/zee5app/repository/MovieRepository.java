package com.zee.zee5app.repository;
import java.util.Set;

import com.zee.zee5app.dto.Movie;
import com.zee.zee5app.dto.Series;
import com.zee.zee5app.exception.IdNotFoundException;

public interface MovieRepository {
	public String addMovie(Movie movie);
	public Set<Movie> getMovies();
	public Movie getMovieById(String id) throws IdNotFoundException;
	public String deleteMovie(String id);
	public String modifyMovie(String id, Movie movie);
}
