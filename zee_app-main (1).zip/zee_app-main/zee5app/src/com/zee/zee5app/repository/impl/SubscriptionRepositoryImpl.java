package com.zee.zee5app.repository.impl;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.zee.zee5app.dto.*;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidNameException;
import com.zee.zee5app.repository.SubscriptionRepository;

public class SubscriptionRepositoryImpl implements SubscriptionRepository {
	private SubscriptionRepositoryImpl()	{ }
	private Set<Subscription> subscriptions = new TreeSet<>();
	
	private static SubscriptionRepository subscriptionRepository;
	public static SubscriptionRepository getInstance()	{
		if (subscriptionRepository == null)
			subscriptionRepository = new SubscriptionRepositoryImpl();
		return subscriptionRepository;
	}

    @Override
	public String addSubscription(Subscription subscription)	{
		if (subscriptions.add(subscription))
			return "Success";
		else
			return "Failed";
	}
    @Override
	public Set<Subscription> getSubscriptions()	{
		return subscriptions;
	}
    @Override
	public Subscription getSubscriptionById(String id) throws IdNotFoundException	{
		for (Subscription subscription: subscriptions)  // traverse using foreach loop
			if (subscription != null && subscription.getId().equals(id))
				return subscription;
		throw new IdNotFoundException("ID not found");
	}

    @Override
	public String modifySubscription(String id, Subscription subscription)	{
		for (Subscription sub: subscriptions)
			if (sub != null && sub.getId().equals(id)) {
				try {
					sub.setId(subscription.getId());
					sub.setDateOfPurchase(subscription.getDateOfPurchase());
					sub.setStatus(subscription.isStatus());
					sub.setPackCountry(subscription.getPackCountry());
					sub.setPaymentMode(subscription.getPaymentMode());
					sub.setAutoRenewal(subscription.isAutoRenewal());
					sub.setPackDuration(subscription.getPackDuration());
					sub.setExpiryDate(subscription.getExpiryDate());
					return "Success";
				} catch (InvalidIdLengthException e) {
					System.out.println("Invalid ID length");
				}
				return "Updated successfully";
			}
		return "User ID not found";
	}
	
    @Override
	public String deleteSubscription(String id)	{
		for (Subscription sub: subscriptions)
			if (sub != null && sub.getId().equals(id)) {
				// if (subscriptions.remove(sub))
					return "Deleted successfully";
				// else
					// return "Failed";
			}
		return "Failed: Subscription ID not found";
	}
	
}
