package com.zee.zee5app;
import java.util.Optional;

import com.zee.zee5app.dto.Register;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.exception.InvalidEmailException;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidNameException;
import com.zee.zee5app.exception.InvalidPasswordException;
import com.zee.zee5app.repository.UserRepository;
import com.zee.zee5app.service.UserService;
import com.zee.zee5app.service.impl.UserServiceImpl;

public class Main {
	public static void main(String[] args) {
		Register register = null;
		try {
			register = new Register();
			register.setId("ab0001");
			register.setFirstName("Praneeth");
			register.setLastName("Vadlapati");
			register.setEmail("praneeth@email.com");
			register.setPassword("test1234");
		} catch (InvalidNameException e) {
			System.out.println("InvalidNameException: " + e);
		} catch (InvalidIdLengthException e) {
			System.out.println("InvalidIdLengthException: " + e);
		} catch (InvalidEmailException e) {
			System.out.println("InvalidEmailException: " + e);
		} catch (InvalidPasswordException e) {
			System.out.println("InvalidPasswordException: " + e);
		} catch (Exception e) {
			System.out.println("Exception: " + e);
		}
		
		// System.out.println(register);
		// System.out.println(register.getEmail());
		
		UserService service = UserServiceImpl.getInstance();
		service.addUser(register);
		
		/* for (int i=1; i<=21; i++)	{
			Register register2 = new Register();
			try {
				register2.setId("ab000"+i);
			} catch (InvalidIdLengthException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			register2.setFirstName("Praneeth");
			register2.setLastName("Vadlapati");
			register2.setEmail("praneeth@email.com");
			register2.setPassword("abcd1234");
			String result = service.addUser(register2);
			System.out.println(result);
			System.out.println(i);
		} */
		
		try {
			Optional<Register> result = service.getUserById("ab0001");
			System.out.println("getUserById: " + result.get());
		} catch (IdNotFoundException e) {
			System.out.println("ID not found");
		}
		
		printUsers(service);
		
		try {
			register.setPassword("test1234");
			register.setLastName("V");
		} catch (InvalidPasswordException e) {
			e.printStackTrace();
		} catch (InvalidNameException e) {
			e.printStackTrace();
		}
		String result = null;
		try {
			result = service.updateUser("ab0001", register);
			System.out.println("Update user: " + result);
		} catch (IdNotFoundException e1) {
			System.out.println("ID not found. Can't update");
		}  // change password
		// printUsers(service);

		try {
			String result2 = service.deleteUserById("ab0001");
			System.out.println("Delete user: " + result2);
		} catch (Exception e) {  // IdNotFoundException
			System.out.println("ID not found");
		}
		// printUsers(service);
		
		// System.out.println("Running completed. All the exceptions are handled.");
	}
	static void printUsers(UserService service)	{
		System.out.println("printUsers: ");
		// return if user details are not available
		if (service.getAllUserDetails() == null)	{
			System.out.println("No users available");
			return;
		}
		service.getAllUserDetails().forEach(register -> System.out.println(register));
		/* for (Register register: service.getAllUserDetails())
			if (register != null)
				System.out.println(register); */
	}
}
