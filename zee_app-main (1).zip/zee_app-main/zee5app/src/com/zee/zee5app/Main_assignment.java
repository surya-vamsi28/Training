package com.zee.zee5app;

import com.zee.zee5app.dto.Movie;
import com.zee.zee5app.dto.Series;
import com.zee.zee5app.dto.Subscription;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.exception.InvalidNameException;
import com.zee.zee5app.service.*;
import com.zee.zee5app.service.impl.*;

public class Main {
	public static void main(String[] args) {
		// System.out.println("");
		// test the subscription service
		System.out.println("SubscriptionService");
		SubscriptionService service = SubscriptionServiceImpl.getInstance();
		Subscription subscription = new Subscription("0001", "2020-01-01", true,
			"India", "Credit Card", true, 1, "2021-01-01");
		System.out.println("addSubscription: " + service.addSubscription(subscription));
		try {
			System.out.println("getSubscriptionById: " + (service.getSubscriptionById("0001") != null));
		} catch (IdNotFoundException e) {
			System.out.println("ID not found");
		}
		for (Subscription sub : service.getSubscriptions())
			if (sub != null)
				System.out.println("getSubscriptions: " + sub);
		subscription.setAutoRenewal(false);
		System.out.println("modifySubscription: " + service.modifySubscription("0001", subscription));
		System.out.println("deleteSubscription: " + service.deleteSubscription("0001"));

		// test the movie service
		System.out.println();
		System.out.println("movieService");
		MovieService movieService = MovieServiceImpl.getInstance();
		Movie movie = new Movie("0001", "Avatar", "Action", "2009-12-10",
				"https://www.youtube.com/watch?v=5PSNL1qE6VY",
				12, 120, "English",
				new String[] {"Sam Worthington", "Zoe Saldana", "Sigourney Weaver"});
		System.out.println(movieService.addMovie(movie));
		try {
			System.out.println(movieService.getMovieById("0001") != null);
		} catch (IdNotFoundException e) {
			System.out.println("ID not found");
		}
		for (Movie mov: movieService.getMovies())
			if (mov != null)
				System.out.println(mov);
		try {
			movie.setMovieName("Avatar 2");
		} catch (InvalidNameException e) {
			System.out.println("Invalid name");
		}
		System.out.println(movieService.modifyMovie("0001", movie));
		System.out.println(movieService.deleteMovie("0001"));
		
		// test the series service
		System.out.println();
		System.out.println("SeriesService");
		SeriesService seriesService = SeriesServiceImpl.getInstance();
		Series series = new Series("0001", "Dark", "Action", "2009-12-10",
				"https://www.youtube.com/watch?v=5PSNL1qE6VY",
				12, 120, 10,
				new int[] {10, 20, 30, 40, 50, 60, 70, 80, 90, 100},
				"English",
				new String[] {"Sam Worthington", "Zoe Saldana", "Sigourney Weaver"});
		System.out.println(seriesService.addSeries(series));
		try {
			System.out.println(seriesService.getSeriesById("0001") != null);
		} catch (IdNotFoundException e) {
			System.out.println("ID not found");
		}
		for (Series ser: seriesService.getSeries())
			if (ser != null)
				System.out.println(ser);
		series.setReleaseDate("2010-01-01");
		System.out.println(seriesService.modifySeries("0001", series));
		System.out.println(seriesService.deleteSeries("0001"));
	}
}
