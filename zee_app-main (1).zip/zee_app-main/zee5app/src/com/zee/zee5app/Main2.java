package com.zee.zee5app;

import com.zee.zee5app.dto.Register;

public class Main2 {

	public static void main(String[] args) {
		try {
			Register register = new Register("ab0001", "Praneeth", "V", "praneeth@email.com", "abcd1234");
			System.out.println(register);
			System.out.println(register.toString());
			System.out.println(register.hashCode());
			
			Register register2 = new Register("ab0001", "Praneeth", "V", "praneeth@email.com", "abcd1234");
			System.out.println(register2);
			System.out.println(register2.toString());
			System.out.println(register2.hashCode());
			
			System.out.println("Equals: " + register.equals(register2));
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
