package com.zee.zee5app;

import javax.sql.DataSource;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.zee.zee5app.dto.Register;
import com.zee.zee5app.exception.InvalidEmailException;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidNameException;
import com.zee.zee5app.exception.InvalidPasswordException;
import com.zee.zee5app.service.UserService;
import com.zee.zee5app.service.impl.UserServiceImpl;

@SpringBootApplication
public class Zee5appspringbootApplication {
	public static void main(String[] args) {		
		ConfigurableApplicationContext applicationContext = 
				SpringApplication.run(Zee5appspringbootApplication.class, args);
		DataSource dataSource = applicationContext.getBean(DataSource.class);
		System.out.println(dataSource != null);

		UserService userService = applicationContext.getBean(UserServiceImpl.class);

		Register register;
		try {
			register = new Register("ab00007", "Praneeth", "Vadlapati",
					"praneeth@email.com", "1234567890", "test12345");
			String res = userService.addUser(register);
			System.out.println("addUser: " + res);
		} catch (Exception e) {
			e.printStackTrace();
		}

		applicationContext.close();
	}
}
