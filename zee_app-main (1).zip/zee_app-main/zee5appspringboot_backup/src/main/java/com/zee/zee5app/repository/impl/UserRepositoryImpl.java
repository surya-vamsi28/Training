package com.zee.zee5app.repository.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.zee.zee5app.dto.Login;
import com.zee.zee5app.dto.ROLE;
import com.zee.zee5app.dto.Register;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.exception.InvalidEmailException;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidNameException;
import com.zee.zee5app.exception.InvalidPasswordException;
import com.zee.zee5app.repository.LoginRepository;
import com.zee.zee5app.repository.UserRepository;

@Repository
public class UserRepositoryImpl implements UserRepository {

	@Autowired
	DataSource dataSource;
	@Autowired
	LoginRepository loginRepository;
	
	@Override
	public String addUser(Register register) {
		// add the user details to the table
		String insertStatement = "INSERT INTO register "
			+ "(regId, firstname, lastname, email, contactnumber, password) "
			+ "VALUES (?, ?, ?, ?, ?, ?)";
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(insertStatement);
			preparedStatement.setString(1, register.getId());
			preparedStatement.setString(2, register.getFirstName());
			preparedStatement.setString(3, register.getLastName());
			preparedStatement.setString(4, register.getEmail());
			preparedStatement.setBigDecimal(5, register.getContactNumber());
			preparedStatement.setString(6, register.getPassword());
			int result = preparedStatement.executeUpdate();
			/* output: the no of rows affected by the DML statement
				1: one row is inserted */
			if (result > 0)	{
//				connection.commit();
				
				Login login = new Login(register.getEmail(), register.getPassword(),
						register.getId(), ROLE.ROLE_USER);
				String res = loginRepository.addCredentials(login);
				if (res.startsWith("Success"))	{
					return "Successfully added user";
				} else {
//					connection.rollback();
					return "Failed to add to Login table: " + res;
				}
				//connection.commit();
			} else {
//				connection.rollback();
				return "Failed to add user";
			}
		} catch (SQLException e) {
			System.out.println("Error while preparing statement");
//			try {
//				connection.rollback();
				if (e.getMessage().startsWith("Duplicate entry"))
					return "Error: same ID already exists";
				return "Error: " + e.getMessage();
//			} catch (SQLException e1) {
//				e1.printStackTrace();
//				return "Error: " + e.getMessage();
//			}
		}
	}
	@Override
	public String updateUser(String id, Register register) throws IdNotFoundException {
		// update the user details in the table
		Connection connection = null;
		try	{
			connection = dataSource.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		String updateStatement = "UPDATE register "
			+ "SET firstname = ?, lastname = ?, email = ?, contactnumber = ?, password = ? "
			+ "WHERE regId = ?";
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(updateStatement);
			preparedStatement.setString(1, register.getFirstName());
			preparedStatement.setString(2, register.getLastName());
			preparedStatement.setString(3, register.getEmail());
			preparedStatement.setBigDecimal(4, register.getContactNumber());
			preparedStatement.setString(5, register.getPassword());
			preparedStatement.setString(6, id);
			int result = preparedStatement.executeUpdate();
			if (result > 0)	{
				connection.commit();
				return "Successfully updated user";
			} else {
				connection.rollback();
				return "Failed to update user";
			}
		} catch (SQLException e) {
			System.out.println("Error while preparing statement");
			try {
				connection.rollback();
				return "Error: " + e.getMessage();
			} catch (SQLException e1) {
				e1.printStackTrace();
				return "Error: " + e.getMessage();
			}
		}
	}
	@Override
	public Optional<Register> getUserById(String id) throws IdNotFoundException {
		// get the user details from the table
		Connection connection = null;
		try	{
			connection = dataSource.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		String selectStatement = "SELECT * FROM register WHERE regId = ?";
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(selectStatement);
			preparedStatement.setString(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			Register register = null;
			if (resultSet.next()) {
				register = new Register();
				try {
					register.setId(resultSet.getString("regId"));
					register.setFirstName(resultSet.getString("firstname"));
					register.setLastName(resultSet.getString("lastname"));
					register.setEmail(resultSet.getString("email"));
					register.setContactNumber(resultSet.getBigDecimal("contactnumber"));
					register.setPassword(resultSet.getString("password"));
				} catch (Exception e) {
					System.out.println("Error while extracting data from result set");
				}
				return Optional.of(register);
			}
			throw new IdNotFoundException("User not found");
		} catch (SQLException e) {
			System.out.println("Error while preparing statement");
		}
		throw new IdNotFoundException("User not found");
	}
	@Override
	public Register[] getAllUsers() throws IdNotFoundException,
			InvalidIdLengthException, InvalidNameException,
			InvalidPasswordException, InvalidEmailException {
		Optional<List<Register>> optional = getAllUserDetails();
		if (optional.isEmpty())
			System.out.println("No data found");
		else if (optional.get().size() == 0)
			System.out.println("Returned 0 rows");
		else {
			List<Register> list = optional.get();
			Register[] registers = new Register[list.size()];
			return list.toArray(registers);
		}
		return null;
	}
	@Override
	public Optional<List<Register>> getAllUserDetails() throws IdNotFoundException,
			InvalidIdLengthException, InvalidNameException,
			InvalidPasswordException, InvalidEmailException {
		Connection connection = null;
		try	{
			connection = dataSource.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		String selectStatement = "SELECT * FROM register";
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(selectStatement);
			List<Register> arrayList = new ArrayList<>();
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				Register register = new Register();
				register.setId(rs.getString("regId"));
				register.setFirstName(rs.getString("firstname"));
				register.setLastName(rs.getString("lastname"));
				register.setEmail(rs.getString("email"));
				register.setContactNumber(rs.getBigDecimal("contactnumber"));
				register.setPassword(rs.getString("password"));
				arrayList.add(register);
			}
			return Optional.ofNullable(arrayList);
		} catch (SQLException e) {
			System.out.println("Error while preparing statement");
		}
		return Optional.empty();
	}
	@Override
	public String deleteUserById(String id) {
		// delete the user details from the table
		Connection connection = null;
		try	{
			connection = dataSource.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		String deleteStatement = "DELETE FROM register WHERE regId = ?";
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(deleteStatement);
			preparedStatement.setString(1, id);
			int result = preparedStatement.executeUpdate();
			if (result > 0) {
				connection.commit();
				return "Successfully deleted user";
			} else {
				connection.rollback();
				return "Failed to delete user";
			}
		} catch (SQLException e) {
			System.out.println("Error while preparing statement");
			try {
				connection.rollback();
				return "Error: " + e.getMessage();
			} catch (SQLException e1) {
				e1.printStackTrace();
				return "Error: " + e.getMessage();
			}
		}
	}
}
