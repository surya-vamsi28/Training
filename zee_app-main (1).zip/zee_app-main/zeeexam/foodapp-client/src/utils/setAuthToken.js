import api from "./api";

// store our JWT in localStorage and set axios headers if we have a token

const setAuthToken = (token) => {
  // if we have a token, set the header and save the token in localStorage
  if (token) {
    api.defaults.headers.common["x-auth-token"] = token;
    // add bearer token
    api.defaults.headers.common["Authorization"] = `Bearer ${token}`;
    localStorage.setItem("token", token);
  } else {
    // if we don't have a token, delete the header and remove the token from localStorage
    delete api.defaults.headers.common["x-auth-token"];
    delete api.defaults.headers.common["Authorization"];
    localStorage.removeItem("token");
  }
};

export default setAuthToken;
