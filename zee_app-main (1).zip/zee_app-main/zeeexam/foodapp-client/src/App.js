import "./App.css";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { AuthRouters } from "./app/auth/routings/AuthRouters";
import { Provider } from "react-redux";
import store from "./redux/store";
import { useEffect } from "react";
import setAuthToken from "./utils/setAuthToken";

import Landing from "./app/core/components/layouts/Landing";
import Header from "./app/core/components/layouts/Header";
import Footer from "./app/core/components/layouts/Footer";
import DashboardRouter from "./app/dashboard/routings/DashboardRouter";
import { loadUser } from "./app/auth/action/authAction";
import Alert from "./app/core/components/Alert";
import ViewCart from "./app/dashboard/components/ViewCart";
import OrderSuccess from "./app/dashboard/components/OrderSuccess";
import OrderHistory from "./app/dashboard/components/OrderHistory";

if (localStorage.token) {
  setAuthToken(localStorage.token);
}

function App() {
  // when token changes, set the token in the header
  useEffect(() => {
    if (localStorage.token) {
      setAuthToken(localStorage.token);
      store.dispatch(loadUser()); // update user info at refresh
    }
  }, [localStorage.token]);

  return (
    <div className="App">
      <Provider store={store}>
        <Router>
          <Header />
          <Alert />
          <Routes>
            <Route path="/" element={<Landing />}></Route>
            <Route path="/auth/*" element={<AuthRouters />}></Route>
            <Route path="/dashboard/*" element={<DashboardRouter />}></Route>
            {/* <Route path="/profiles/*" element={<ProfileRouter />}></Route> */}
            <Route path="/view-cart/" element={<ViewCart />}></Route>
            <Route path="/order-success/" element={<OrderSuccess />}></Route>
            <Route path="/order-history/" element={<OrderHistory />}></Route>
          </Routes>
          <Footer />
        </Router>
      </Provider>
    </div>
  );
}

export default App;
