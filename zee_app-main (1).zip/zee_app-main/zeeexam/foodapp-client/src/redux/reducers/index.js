import { combineReducers } from "redux";
import auth from "../../app/auth/reducers/authReducer";
import alerts from "../../app/core/reducers/alertReducer";
import foods from "../../app/dashboard/reducers/FoodReducer";

// to combine all the reducers and export it
export default combineReducers({
  auth,
  alerts,
  foods,
});
