import thunk from "redux-thunk";
import { createStore } from "redux";
import combineReducers from "../reducers";
import { composeWithDevTools } from "redux-devtools-extension";
import { applyMiddleware } from "redux";

import setAuthToken from "../../utils/setAuthToken";

const initialState = {};
// default state for your application

const middleware = [thunk];

// apply middleware to the store
const store = createStore(
  combineReducers,
  initialState,
  // provides accessibility to middleware & redux devtools
  composeWithDevTools(applyMiddleware(...middleware))
);

// subscribe listener
let currentState = store.getState();

store.subscribe(() => {
  // store the previous state and get the current state
  let previousState = currentState;
  currentState = store.getState();

  // if the token changes, take token and set it to local storage
  if (previousState.auth.token !== currentState.auth.token) {
    const token = currentState.auth.token;
    setAuthToken(token);
  }
});

export default store;

// getting token for private endpoints
