export const FOODS_LOADED = "FOODS_LOADED";
export const SET_FOOD_TYPE = "SET_FOOD_TYPE";
export const UPDATE_CART = "UPDATE_CART";
export const CREATE_ORDER = "CREATE_ORDER";
export const ORDERS_LOADED = "ORDERS_LOADED";
