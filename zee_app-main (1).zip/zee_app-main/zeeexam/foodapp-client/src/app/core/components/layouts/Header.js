import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Link } from "react-router-dom";

import { logout } from "../../../auth/action/authAction";

const Header = ({
  logout,
  auth: { isAuthenticated, user },
  foods: { cart },
}) => {
  var cartLength = 0;
  var cartTotal = 0;
  if (cart.length > 0) {
    // for each item in cart, add quantity to cartLength
    cart.forEach((item) => {
      cartLength += item.quantity;
      // for each item in cart, add price * quantity to cartTotal
      cartTotal += item.foodCost * item.quantity;
    });
  }

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light">
      <div className="container">
        <Link className="navbar-brand" to="/">
          Food Delivery app
        </Link>
        <button className="navbar-toggler" type="button">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div
          className="collapse navbar-collapse" /* id="navbarSupportedContent" */
        >
          {/* show register and login options if not authenticated */}
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            {!isAuthenticated ? (
              <>
                <li className="nav-item">
                  <Link className="nav-link" to="/auth/register">
                    Register
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/auth/login">
                    Login
                  </Link>
                </li>
              </>
            ) : null}

            {/* show user name if authenticated */}
            {isAuthenticated ? (
              <li className="nav-item">
                <p className="nav-link">Welcome {user && user.username}</p>
              </li>
            ) : null}

            {/* show order history option if logged in as user */}
            {isAuthenticated && !user.isAdmin ? (
              <li className="nav-item">
                <Link className="nav-link" to="/order-history">
                  Order history
                </Link>
              </li>
            ) : null}

            {/* show 'add food' option if logged in as admin */}
            {isAuthenticated && user.isAdmin ? (
              <li className="nav-item">
                <Link className="nav-link" to="/add-food-item">
                  Add food item
                </Link>
              </li>
            ) : null}

            {/* show logout option if logged in */}
            {isAuthenticated ? (
              <li className="nav-item">
                <Link to="/" className="nav-link" onClick={logout}>
                  Logout
                </Link>
              </li>
            ) : null}

            {/* show cart icon if logged in as user and cart is not empty */}
            {cart.length && !user.isAdmin ? (
              <li className="nav-item">
                <Link to="/view-cart" className="nav-link">
                  <i className="bi bi-cart"></i> {cartLength} | ₹ {cartTotal}
                </Link>
              </li>
            ) : null}
          </ul>
        </div>
      </div>
    </nav>
  );
};

Header.propTypes = {
  logout: PropTypes.func.isRequired,
  auth: PropTypes.object.isRequired,
  foods: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => ({
  auth: state.auth,
  foods: state.foods,
});

const mapDispatchToProps = {
  logout,
};

export default connect(mapStateToProps, mapDispatchToProps)(Header);
