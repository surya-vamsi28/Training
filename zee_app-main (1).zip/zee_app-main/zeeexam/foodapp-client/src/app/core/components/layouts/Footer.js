import React from "react";

const Footer = () => {
  return (
    // <footer className="bg-dark text-white mt-5 p-4 text-center">
    //   Copyright &copy; {new Date().getFullYear()} Food Delivery App
    // </footer>
    <div className="text-center fixed-bottom" /*  */>
      &copy; {new Date().getFullYear()} &middot; All rights reserved
    </div>
  );
};

export default Footer;
