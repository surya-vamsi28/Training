import PropTypes from "prop-types";
import { connect } from "react-redux";
import Moment from "react-moment";
import { loadOrders } from "../actions/FoodActions";

const OrderHistory = ({ foods: { orders }, loadOrders }) => {
  if (!orders) {
    loadOrders();
    return <div>Loading...</div>;
  }
  return (
    <div>
      <h3>Your order history</h3>

      <table class="table">
        <thead>
          <tr>
            <th>Sl no</th>
            <th>Order ID</th>
            <th>Order Date</th>
            <th>Order total</th>
          </tr>
        </thead>

        <tbody>
          <tr>
            {orders.map((order, index) => (
              <>
                <td>{index + 1}</td>
                <td>{order.orderId}</td>
                <td>
                  <Moment format="DD-MM-YYYY">{order.orderTimestamp}</Moment>
                </td>
                <td>₹ {order.orderAmount}</td>
              </>
            ))}
          </tr>
        </tbody>
      </table>
    </div>
  );
};

OrderHistory.propTypes = {
  foods: PropTypes.object.isRequired,
  loadOrders: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  foods: state.foods,
});

const mapDispatchToProps = { loadOrders };

export default connect(mapStateToProps, mapDispatchToProps)(OrderHistory);
