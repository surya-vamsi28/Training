const Pagination = ({ pageNo, setPageNo }) => {
  return (
    <nav className="pagination">
      <ul className="pagination">
        <li className="page-item">
          <button
            className="page-link"
            onClick={() => setPageNo(pageNo - 1)}
            // aria-disabled={pageNo === 1}
          >
            Previous
          </button>
        </li>
        <li className="page-item">
          <button onClick={() => setPageNo(1)} className="page-link">
            1
          </button>
        </li>
        <li className="page-item">
          <button onClick={() => setPageNo(2)} className="page-link">
            2
          </button>
        </li>
        <li className="page-item">
          <button onClick={() => setPageNo(3)} className="page-link">
            3
          </button>
        </li>
        <li className="page-item">
          <button
            className="page-link"
            onClick={() => setPageNo(pageNo + 1)}
            // aria-disabled={foods.length < 18}
          >
            Next
          </button>
        </li>
      </ul>
    </nav>
  );
};

export default Pagination;
