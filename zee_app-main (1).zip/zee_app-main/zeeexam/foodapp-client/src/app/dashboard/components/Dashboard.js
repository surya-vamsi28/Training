import React, { useState } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
// import { Link } from "react-router-dom";
import { Navigate, useNavigate } from "react-router-dom";
import { loadFoods, setFoodType } from "../actions/FoodActions";
import { loadUser } from "../../auth/action/authAction";
import DisplayFoodCard from "./DisplayFoodCard";
import Pagination from "./Pagination";

import "./Dashboard.css";

const Dashboard = ({
  foods: { foods, cart, foodType },
  loadFoods,
  setFoodType,
  auth,
  loadUser,
}) => {
  const navigate = useNavigate();
  const [pageNo, setPageNo] = useState(1);

  if (!localStorage.token) {
    // if not logged in, redirect to login page
    return <Navigate to="/auth/login" />;
  }

  if (!auth.user) {
    loadUser();
  }

  if (!foods) {
    // load foods from api if not already loaded
    loadFoods(navigate);
  }

  const handleTypeChange = (e) => {
    console.log("selected foodType:", foodType);
    setFoodType(e.target.value);
  };

  const foodTypes = ["Indian", "Mexican", "Chinese"];

  const NoFoods = () => {
    return (
      <div className="text-center">
        <h1>No Foods</h1>
        <p>
          There are no foods in the database. Please contact your administrator
        </p>
      </div>
    );
  };

  // display all foods in a grid with a card for each food
  return (
    <>
      <div className="row main">
        <div className="row">
          <div className="col"></div>
          <div className="col"></div>
          <div className="col"></div>
          <div className="col"></div>
          <div className="col">
            <select
              className="form-select"
              onChange={handleTypeChange}
              defaultValue=""
            >
              <option value="">---</option>
              {foodTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div className="grid-container col-md-10 mt-3">
          {foods ? (
            foods.map((food) => {
              // if food type is selected and it is not equal to the food type, don't display
              if (foodType && foodType.length && food.foodType !== foodType) {
                return null;
              }
              return <DisplayFoodCard food={food} cart={cart} key={food.id} />;
            })
          ) : (
            <NoFoods />
          )}
        </div>

        <Pagination pageNo={pageNo} setPageNo={setPageNo} />
      </div>
    </>
  );
};

Dashboard.propTypes = {
  foods: PropTypes.object.isRequired,
  loadFoods: PropTypes.func.isRequired,
  setFoodType: PropTypes.func.isRequired,
  auth: PropTypes.object.isRequired,
  loadUser: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  foods: state.foods,
  auth: state.auth,
});

const mapDispatchToProps = { loadFoods, setFoodType, loadUser };

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);
