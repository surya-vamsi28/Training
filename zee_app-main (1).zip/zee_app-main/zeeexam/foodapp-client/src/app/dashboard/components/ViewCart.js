import PropTypes from "prop-types";
import { Navigate, useNavigate } from "react-router-dom";
import { connect } from "react-redux";
import { loadUser } from "../../auth/action/authAction";
import { deleteFromCart, createOrder } from "../actions/FoodActions";
import AddToCart from "./AddToCart";
import "./ViewCart.css";

const ViewCart = ({
  auth,
  foods: { cart },
  deleteFromCart,
  loadUser,
  createOrder,
}) => {
  const checkout = () => {
    if (cartTotal === 0) {
      alert("Your cart is empty");
      return;
    }
    var orderAmount = cartTotal + 0; // make a copy of cartTotal value
    var orderTimestamp = new Date().getTime();
    var token = localStorage.token;
    var order = { orderAmount, orderTimestamp, token };

    // create order
    createOrder(order);
    navigate("/order-success");
  };

  const navigate = useNavigate();

  if (!auth || !auth.isAuthenticated) {
    if (localStorage.token) {
      loadUser(navigate);
      return <></>;
    } else {
      return <Navigate to="/auth/login" />;
    }
  }
  if (!auth.user) {
    loadUser(navigate);
    return <></>;
  }
  if (auth.user.isAdmin) {
    console.log("You are Admin. You can't see view the cart");
    return <Navigate to="/dashboard" />;
  }

  var cartTotal = 0;
  cart.forEach((item) => {
    // for each item in cart, add price * quantity to cartTotal
    cartTotal += item.foodCost * item.quantity;
  });

  return (
    <div className="view-cart-container">
      <h3>Your cart content</h3>

      <table className="table">
        <thead>
          <tr>
            <td>Sl no</td>
            <td> </td>
            <td>Foor name</td>
            <td style={{ textAlign: "right", paddingRight: "50px" }}>
              {" "}
              Food cost{" "}
            </td>
            <td>Quantity</td>
            <td style={{ textAlign: "right" }}> Total</td>
            <td style={{ minWidth: "75px" }}></td>
          </tr>
        </thead>
        <tbody>
          {cart.map((item, index) => (
            <tr key={index}>
              <td>{index + 1}</td>
              <td>
                <img
                  src={item.foodPic}
                  alt={item.foodName}
                  className="img-thumbnail"
                />
              </td>
              <td>{item.foodName}</td>
              <td align="right" style={{ paddingRight: "50px" }}>
                ₹ {item.foodCost}
              </td>
              <td>
                <AddToCart food={item} />
              </td>
              <td align="right">₹ {item.foodCost * item.quantity}</td>
              <td
                style={{ textAlign: "center", cursor: "pointer" }}
                onClick={() => deleteFromCart(item, cart)}
              >
                <i className="bi bi-trash"></i>
              </td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <th colSpan="5"></th>
          <th style={{ textAlign: "right" }}>₹ {cartTotal}</th>
        </tfoot>
      </table>

      <button className="btn btn-primary" onClick={checkout}>
        Checkout
      </button>
    </div>
  );
};

ViewCart.propTypes = {
  auth: PropTypes.object.isRequired,
  foods: PropTypes.object.isRequired,
  deleteFromCart: PropTypes.func.isRequired,
  loadUser: PropTypes.func.isRequired,
  createOrder: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  auth: state.auth,
  foods: state.foods,
});

const mapDispatchToProps = {
  deleteFromCart,
  loadUser,
  createOrder,
};

export default connect(mapStateToProps, mapDispatchToProps)(ViewCart);
