import PropTypes from "prop-types";
import { Navigate, useNavigate } from "react-router-dom";
import { connect } from "react-redux";
import { loadUser } from "../../auth/action/authAction";
import "./OrderSuccess.css";

const OrderSuccess = ({ auth, loadUser }) => {
  const navigate = useNavigate();
  if (!auth || !auth.isAuthenticated) {
    if (localStorage.token) {
      loadUser(navigate);
      return <></>;
    } else {
      return <Navigate to="/auth/login" />;
    }
  }
  if (!auth.user) {
    loadUser(navigate);
    return <></>;
  }
  var address = auth.user.address;
  return (
    <div className="mt-5 green-box">
      <div className="display-6">
        Thank you for placing an order.
        <br /> <br />
        Your order will be delivered shortly
      </div>

      <div className="mt-5">
        <h3>Delivery address:</h3>
        <hr />
        <div className="lead">{address}</div>
      </div>
    </div>
  );
};

OrderSuccess.propTypes = {
  auth: PropTypes.object.isRequired,
  loadUser: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  auth: state.auth,
});

const mapDispatchToProps = { loadUser };

export default connect(mapStateToProps, mapDispatchToProps)(OrderSuccess);
