import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import { connect } from "react-redux";

import AddToCart from "./AddToCart";

const DisplayFoodCard = ({ food, cart }) => {
  var isInCart = false;
  var quantity = 0;
  cart.forEach((item) => {
    if (item.id === food.id && item.foodName === food.foodName) {
      isInCart = true;
      quantity = item.quantity;
    }
  });

  const navigate = useNavigate();

  return (
    <div className="card">
      <div
        onClick={() => navigate("./food-details/" + food.id)}
        style={{ cursor: "pointer" }}
      >
        <div className="card-body">
          <h5 className="card-title">{food.foodName}</h5>
        </div>
        <div className="card-img-container">
          <img
            src={food.foodPic}
            className="card-img-top d-inline-block"
            alt={food.foodName}
          />
        </div>
      </div>
      <AddToCart food={food} />
    </div>
  );
};

DisplayFoodCard.propTypes = {
  food: PropTypes.object.isRequired,
  cart: PropTypes.array.isRequired,
};

const mapStateToProps = (state) => ({});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(DisplayFoodCard);
