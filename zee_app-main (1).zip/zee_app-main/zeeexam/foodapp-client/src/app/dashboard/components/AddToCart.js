import PropTypes from "prop-types";
import { connect } from "react-redux";
import { addToCart, decrementQuantity } from "../actions/FoodActions";

const AddToCart = ({
  food, // food to add to cart
  foods: { cart },
  auth: {
    user: { isAdmin },
  },
  addToCart,
  decrementQuantity,
}) => {
  var isInCart = cart.some((item) => item.id === food.id);
  var quantity = 0;
  if (isInCart) {
    cart.forEach((item) => {
      if (item.id === food.id) {
        quantity = item.quantity;
      }
    });
  }

  return (
    <>
      {!isAdmin && isInCart ? (
        <div>
          <button
            className="btn btn-primary btn-update-cart"
            onClick={() => decrementQuantity(food, cart)}
          >
            -
          </button>
          <span className="quantity-container">{quantity}</span>
          <button
            className="btn btn-primary btn-update-cart"
            onClick={() => addToCart(food, cart)}
          >
            +
          </button>
        </div>
      ) : null}

      {!isAdmin && !isInCart ? (
        <div>
          <button
            className="btn btn-primary"
            onClick={() => addToCart(food, cart)}
          >
            Add to cart
          </button>
        </div>
      ) : null}
    </>
  );
};

AddToCart.propTypes = {
  food: PropTypes.object.isRequired,
  foods: PropTypes.object.isRequired,
  auth: PropTypes.object.isRequired,
  addToCart: PropTypes.func.isRequired,
  decrementQuantity: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  auth: state.auth,
  foods: state.foods,
});

const mapDispatchToProps = { addToCart, decrementQuantity };

export default connect(mapStateToProps, mapDispatchToProps)(AddToCart);
