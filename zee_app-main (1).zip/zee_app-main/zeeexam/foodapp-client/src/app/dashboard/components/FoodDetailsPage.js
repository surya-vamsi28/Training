import PropTypes from "prop-types";
import { connect } from "react-redux";
import { useParams } from "react-router-dom";
import { Navigate, useNavigate } from "react-router-dom";
import { loadUser } from "../../auth/action/authAction";

import AddToCart from "./AddToCart";
import {
  loadFoods,
  addToCart,
  decrementQuantity,
  deleteFood,
} from "../actions/FoodActions";
import "./FoodDetailsPage.css";

const FoodDetailsPage = ({
  foods: { foods, cart },
  auth,
  loadUser,
  loadFoods,
}) => {
  const { id } = useParams();
  const navigate = useNavigate();

  if (!auth || !auth.isAuthenticated) {
    if (localStorage.token) {
      loadUser(navigate);
    } else {
      return <Navigate to="/auth/login" />;
    }
  }
  if (!auth.user) {
    loadUser(navigate);
  }
  var isAdmin = auth.user.isAdmin;

  if (!id) {
    // if there is no id in the url
    return <div>No food selected</div>;
  }
  if (!foods) {
    loadFoods(navigate);
  }

  var food = null;
  foods.forEach((item) => {
    if (item.id == id) {
      food = item;
    }
  });
  if (!food) {
    // if not found
    return <div>Food not found with ID {id}</div>;
  }
  var isInCart = false;
  var quantity = 0;

  // check whether item is in cart
  cart.forEach((item) => {
    if (item.id == id) {
      isInCart = true;
      quantity = item.quantity;
    }
  });

  const confirmAndDeleteFood = () => {
    if (
      isAdmin &&
      window.confirm("Are you sure you want to delete this food?")
    ) {
      deleteFood(food.id);
    }
  };

  return (
    <div className="row food-details-container">
      <div className="col">
        <img
          src={food.foodPic}
          alt={food.foodName}
          className="img-thumbnail"
          style={{ maxHeight: "unset", maxWidth: "unset" }}
        />
      </div>
      <div className="col">
        <h3>{food.foodName}</h3>
        <h1>₹ {food.foodCost}</h1>
        <div>{food.description}</div>

        {isAdmin ? (
          // if admin, show the options to delete and edit food
          <div className="button-container">
            <button
              className="btn btn-primary"
              onClick={() => navigate("../edit-food-item/" + food.id)}
            >
              <i className="bi bi-pencil-square"></i>
              Edit food
            </button>
            <button className="btn btn-danger" onClick={confirmAndDeleteFood}>
              <i className="bi bi-trash"></i>
              Delete food
            </button>
          </div>
        ) : (
          // if not admin, show option to add to cart
          <div className="button-container">
            <AddToCart food={food} />
          </div>
        )}
      </div>
    </div>
  );
};

FoodDetailsPage.propTypes = {
  foods: PropTypes.object,
  addToCart: PropTypes.func.isRequired,
  decrementQuantity: PropTypes.func.isRequired,
  auth: PropTypes.object,
  loadUser: PropTypes.func.isRequired,
  loadFoods: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  auth: state.auth,
  foods: state.foods,
});

const mapDispatchToProps = {
  addToCart,
  decrementQuantity,
  loadUser,
  loadFoods,
};

export default connect(mapStateToProps, mapDispatchToProps)(FoodDetailsPage);
