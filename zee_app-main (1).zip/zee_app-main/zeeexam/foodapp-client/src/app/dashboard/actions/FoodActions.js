import {
  FOODS_LOADED,
  SET_FOOD_TYPE,
  UPDATE_CART,
  CREATE_ORDER,
  ORDERS_LOADED,
} from "../../../redux/types/foodTypes";
import api from "../../../utils/api";
import { setAlert } from "../../core/actions/alertAction";
import setAuthToken from "../../../utils/setAuthToken";

export const loadFoods = (navigate) => async (dispatch) => {
  try {
    if (!localStorage.token) {
      navigate("/login");
    }
    setAuthToken(localStorage.token);
    const res = await api.get("/food");
    dispatch({ type: FOODS_LOADED, payload: res.data });
  } catch (err) {
    console.log(err);
  }
};

export const setFoodType = (foodType) => (dispatch) => {
  dispatch({ type: SET_FOOD_TYPE, payload: foodType });
};

export const addToCart = (food, cart) => (dispatch) => {
  var isInCart = false;
  cart.forEach((item) => {
    if (item.id === food.id) {
      isInCart = true;
      item.quantity++;

      dispatch({
        type: UPDATE_CART,
        payload: cart,
      });
    }
  });

  if (!isInCart) {
    cart.push({ ...food, quantity: 1 });
    dispatch({
      type: UPDATE_CART,
      payload: cart,
    });
  }
};

export const decrementQuantity = (food, cart) => (dispatch) => {
  var isInCart = false;
  if (cart) {
    cart.forEach((item) => {
      if (item.id === food.id) {
        isInCart = true;
        item.quantity--;
        if (item.quantity === 0) {
          // if no quantity, remove from cart
          cart.splice(cart.indexOf(item), 1);
        }

        dispatch({
          type: UPDATE_CART,
          payload: cart,
        });
      }
    });
  }
  if (!isInCart) {
    console.log("decrementQuantity: item not in cart:", food.foodName);
  }
};

export const deleteFromCart = (food, cart) => (dispatch) => {
  var isInCart = false;
  cart.forEach((item) => {
    if (item.id === food.id) {
      isInCart = true;
      cart.splice(cart.indexOf(item), 1);
      dispatch({
        type: UPDATE_CART,
        payload: cart,
      });
    }
  });
  if (!isInCart) {
    console.log("deleteFromCart: item not in cart:", food.foodName);
  }
};

export const deleteFood = (food) => async (dispatch) => {
  try {
    const res = await api.delete(`/food/${food.id}`);
    dispatch({ type: FOODS_LOADED, payload: res.data });
  } catch (err) {
    console.log(err);
  }
};

export const createOrder = (order) => async (dispatch) => {
  try {
    const res = await api.post("/food/order", order);
    dispatch({ type: CREATE_ORDER, payload: res.data });
  } catch (err) {
    console.log(err);
  }
};

export const loadOrders = () => async (dispatch) => {
  try {
    const res = await api.post("/food/orderhistory", {
      token: localStorage.token,
    });
    console.log("loadOrders:", res);
    if (!res.data) {
      dispatch(setAlert("No orders found", "danger"));
    }
    dispatch({ type: ORDERS_LOADED, payload: res.data });
  } catch (err) {
    console.log({ ...err });
  }
};
