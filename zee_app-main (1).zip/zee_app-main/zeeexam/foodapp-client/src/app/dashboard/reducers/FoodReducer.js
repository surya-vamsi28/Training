import {
  FOODS_LOADED,
  SET_FOOD_TYPE,
  UPDATE_CART,
  CREATE_ORDER,
  ORDERS_LOADED,
} from "../../../redux/types/foodTypes";

const initialState = {
  foods: null,
  foodType: "",
  cart: [],
};

export default (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    case FOODS_LOADED:
      return {
        ...state,
        foods: payload,
        foodType: "",
        cart: [],
      };
    case SET_FOOD_TYPE:
      return {
        ...state,
        foodType: payload,
      };

    case UPDATE_CART:
      return {
        ...state,
        cart: payload,
      };

    case CREATE_ORDER:
      return {
        ...state,
        cart: [],
      };

    case ORDERS_LOADED:
      return {
        ...state,
        orders: payload,
      };

    default:
      return state;
  }
};
