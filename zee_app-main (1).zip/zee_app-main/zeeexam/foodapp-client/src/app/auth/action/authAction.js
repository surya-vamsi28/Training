// Register user
import {
  LOGIN_SUCCESS,
  REGISTER_FAIL,
  REGISTER_SUCCESS,
  USER_LOADED,
  LOGIN_FAIL,
  LOGOUT,
} from "../../../redux/types/userTypes";
import api from "../../../utils/api";
import { setAlert } from "../../core/actions/alertAction";
import setAuthToken from "../../../utils/setAuthToken";

export const register = (formData) => async (dispatch) => {
  try {
    if (formData.password !== formData.password2) {
      dispatch(setAlert("Passwords did not match", "danger"));
      return;
    }
    // remove password2 from the formData
    delete formData.password2;
    // set email as the username
    formData.username = formData.email;

    const res = await api.post("/register", formData);

    dispatch({ type: REGISTER_SUCCESS, payload: res.data });
    dispatch(setAlert("You Registered successfully", "success"));
    dispatch(loadUser());
  } catch (err) {
    const error = err.response.data;
    dispatch(setAlert(error.message, "danger"));
    dispatch({ type: REGISTER_FAIL });
  }
};

export const login = (email, password) => async (dispatch) => {
  const body = JSON.stringify({
    username: email,
    password: password,
  });
  try {
    const res = await api.post("/authenticate", body);

    res.data.token = res.data.accessToken;
    delete res.data.accessToken;

    dispatch({ type: LOGIN_SUCCESS, payload: res.data });
    dispatch(loadUser());
    if (res.data.token) {
      console.log("token", res.data.token);
      setAuthToken(res.data.token);
    }
  } catch (err) {
    dispatch(setAlert("Failed to login", "danger"));
    dispatch({ type: LOGIN_FAIL });
  }
};

export const logout = () => (dispatch) => {
  if (localStorage.token) {
    localStorage.removeItem("token");
  }
  dispatch({ type: LOGOUT });
};

// load the user information using token
export const loadUser = (navigate) => async (dispatch) => {
  try {
    if (!localStorage.token) navigate("/auth/login");
    const token = localStorage.token;
    const res = await api.post("/loadUser", { token });

    // store whether user is admin or not
    var user = res.data;
    user.isAdmin = false;
    if (user && user.roles) {
      // for each role in user.roles, check if role.roleName is ROLE_ADMIN
      user.roles.forEach((role) => {
        if (role.roleName === "ROLE_ADMIN") {
          user.isAdmin = true;
        }
      });
    }

    dispatch({ type: USER_LOADED, payload: user });
  } catch (err) {
    console.log({ ...err });
  }
};
