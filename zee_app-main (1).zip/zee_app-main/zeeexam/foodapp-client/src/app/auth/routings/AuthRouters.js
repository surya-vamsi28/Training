import React from "react";

import { Route, Routes } from "react-router-dom";
import Login from "../components/Login";
import Register from "../components/Register";

export const AuthRouters = () => {
  return (
    <Routes>
      <Route path="register" element={<Register />} />
      <Route path="login" element={<Login />} />
    </Routes>
  );
};
