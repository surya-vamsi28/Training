package com.learning.controlleradvice;

import java.util.HashMap;
import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.learning.exception.AlreadyExistsException;
import com.learning.exception.FoodIdNotFoundException;
import com.learning.exception.FoodItemNotFoundException;
import com.learning.exception.IdNotFoundException;
import com.learning.exception.apierror.ApiError;

@ControllerAdvice
public class ExceptionAdvice extends ResponseEntityExceptionHandler {
	@ExceptionHandler(AlreadyExistsException.class)
	public ResponseEntity<?> alreadyRecordExistsExceptionHandler(AlreadyExistsException e) {
		HashMap<String, String> map = new HashMap<>();
		map.put("message", "Record already exists" + e.getMessage());
		return ResponseEntity.badRequest().body(map);

	}

//	@ExceptionHandler(Exception.class) // if no match then it will act as a default exceptionhandler
//	public ResponseEntity<?> exceptionHandler(Exception e){
//		HashMap<String, String> map = new HashMap<>();
//		map.put("message", "unknown Exception"+e.getMessage());
//		return ResponseEntity.badRequest().body(map);
//		
//	}

	@ExceptionHandler(IdNotFoundException.class)
	public ResponseEntity<?> idNotFoundExceptionHandler(IdNotFoundException e) {
		HashMap<String, String> map = new HashMap<>();
		map.put("message", "" + e.getMessage());
		return ResponseEntity.badRequest().body(map);
	}

	@ExceptionHandler(FoodIdNotFoundException.class)
	public ResponseEntity<?> foodIdNotFoundExceptionHandler(FoodIdNotFoundException e) {
		String message = "Sorry Food " + e.id + " Not Found";
		Map<String, String> map = new HashMap<>();
		map.put("message", message);
		return ResponseEntity.status(404).body(map);
	}

	@ExceptionHandler(FoodItemNotFoundException.class)
	public ResponseEntity<?> foodItemNotFoundExceptionHandler(FoodItemNotFoundException e) {
		String message = "Sorry Food Item " + e.item + " Not Found";
		Map<String, String> map = new HashMap<>();
		map.put("message", message);
		return ResponseEntity.status(404).body(map);
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		ApiError apiError = new ApiError(HttpStatus.BAD_REQUEST);
		apiError.setMessage("Validation Error");
		apiError.addValidationErrors(ex.getBindingResult().getFieldErrors()); // fieldwise errors
		apiError.addValidationError(ex.getBindingResult().getGlobalErrors());
		return buildResponseEntity(apiError);
	}

	private ResponseEntity<Object> buildResponseEntity(ApiError apiError) {
		return new ResponseEntity<>(apiError, apiError.getHttpStatus());
	}

	@ExceptionHandler(ConstraintViolationException.class)
	protected ResponseEntity<?> handleConstraintViolation() {
		return null;

	}
}
