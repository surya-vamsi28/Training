package com.learning.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "register", uniqueConstraints = { @UniqueConstraint(columnNames = "username"),
		@UniqueConstraint(columnNames = "email") })
public class User implements Comparable<User> {
	@Id
	@Column(name = "regId")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@NotBlank
	@Size(min = 3, max = 40)
	private String username;

	@NotBlank
	@Size(min = 3, max = 30)
	private String name;
	@NotBlank
	@Size(min = 3, max = 50)
	private String address;

	@NotBlank
	@Size(min = 3, max = 40)
	@Email
	private String email;

	@NotBlank
	@Size(min = 6, max = 70)
	// longer string storage. hash is long.
	private String password;

	@Override
	public int compareTo(User other) {
		return this.id.compareTo(other.getId());
	}

	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "user_roles", joinColumns = @JoinColumn(name = "regId"), inverseJoinColumns = @JoinColumn(name = "roleId")) // registered
																																	// user(regid)
																																	// and
																																	// role(roleid)
	private Set<Role> roles = new HashSet<>();

	public User(String username, String email, String password, String name, String address) {
		this.username = username;
		this.email = email;
		this.password = password;
		this.name = name;
		this.address = address;
	}
}
