package com.learning.service;

import java.util.List;
import java.util.Optional;

import com.learning.entity.Role;
import com.learning.exception.IdNotFoundException;

public interface RoleService {
    public String addRole(Role role);
    public String updateRole(int id, Role role);
    public Optional<Role> getRoleById(int id);
    public Role[] getAllRoles();
    public List<Role> getAllRoleDetails();
    public String deleteRoleById(int id) throws IdNotFoundException;
}