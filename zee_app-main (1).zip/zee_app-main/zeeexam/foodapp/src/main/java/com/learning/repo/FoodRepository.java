package com.learning.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.learning.entity.Food;

@Repository
public interface FoodRepository extends JpaRepository<Food, String>	{
	Boolean existsByFoodName(String foodName);
	Optional<Food> findById(long id);
	Optional<List<Food>> findByFoodType(String foodType);
}