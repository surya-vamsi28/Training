package com.learning.exception;

import lombok.ToString;

@ToString(callSuper = true)
public class FoodItemNotFoundException extends Exception {
	public String item = "";
	public FoodItemNotFoundException(String message) {
		super(message);
	}
	public FoodItemNotFoundException(String message, String item) {
		super(message);
		this.item = item;
	}
}