package com.learning.exception;

public class LocationNotFoundException extends Exception {
	public LocationNotFoundException(String message) {
		super(message);

}
}