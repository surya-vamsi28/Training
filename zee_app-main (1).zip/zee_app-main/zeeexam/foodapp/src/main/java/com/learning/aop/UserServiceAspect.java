package com.learning.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@Aspect // container which holds all the AOP code
public class UserServiceAspect {

	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@Pointcut("within(@org.springframework.stereotype.Repository *) "
			+ "|| within(@org.springframework.stereotype.Service *)"
			+ "|| within(@org.springframework.web.bind.annotation.RestController  *)")
	public void springPointCutExp() {

	}

	@Pointcut("within(com.learning.controller..*) " + "|| within(com.learning.service.impl..*)")
	public void springPointCutExp2() {

	}

	// executed after throwing an exception e
	@AfterThrowing(pointcut = "springPointCutExp() && springPointCutExp2()", throwing = "e")
	public void logAfterThrowingException(JoinPoint joinPoint, Throwable e) {
		log.error("exception {}.{}() with cause {}", joinPoint.getSignature().getDeclaringTypeName(),
				joinPoint.getSignature().getName(), e.getCause() != null ? e.getCause() : "NULL");
	}

	// executed before the execution of a method
	// .proceed method lets the code execute
	// this method can also be used to measure the amount of time taken to execute the method
	@Around(value = "springPointCutExp() && springPointCutExp2()")
	public Object around(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {

		log.info("{}.{}() with args {}", proceedingJoinPoint.getSignature().getDeclaringTypeName(),
				proceedingJoinPoint.getSignature().getName(), proceedingJoinPoint.getArgs());

		Object result = proceedingJoinPoint.proceed();

		log.info("{}.{}() with return value {}", proceedingJoinPoint.getSignature().getDeclaringTypeName(),
				proceedingJoinPoint.getSignature().getName(), result);

		return result;
	}

	// executed before the execution of any method
	@Before(value = "execution(* com.learning.service.impl.*.get*(..))")
	public void beforeAllServiceMethods(JoinPoint joinPoint) {
		System.out.println("hello - before");
		System.out.println(joinPoint);
	}

	// executed after the execution of any method
	@After(value = "execution(* com.learning.service.impl.*.get*(..))")
	public void afterAllServiceMethods(JoinPoint joinPoint) {
		System.out.println(joinPoint);
		System.out.println("hello - after");
	}
}
