package com.learning.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "orders")
public class Order implements Comparable<Order> {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long orderId;
	private double orderAmount;
	private long orderTimestamp;
	private long userId;

	public Order(double orderAmount, long orderTimestamp, long userId) {
		super();
		this.orderAmount = orderAmount;
		this.orderTimestamp = orderTimestamp;
		this.userId = userId;
	}

	@Override
	public int compareTo(Order o) {
		return (int) (this.orderTimestamp - o.getOrderTimestamp());
	}

}