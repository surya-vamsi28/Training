package com.learning.exception;

import lombok.ToString;

@ToString(callSuper = true)
public class FoodIdNotFoundException extends Exception {
	public String id = "";
	public FoodIdNotFoundException(String message) {
		super(message);
	}
	public FoodIdNotFoundException(String message, String food) {
		super(message);
		this.id = food;
	}
}