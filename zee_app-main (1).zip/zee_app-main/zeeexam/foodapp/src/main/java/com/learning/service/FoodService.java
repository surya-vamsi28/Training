package com.learning.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.learning.entity.Food;
import com.learning.exception.AlreadyExistsException;
import com.learning.exception.FoodItemNotFoundException;
import com.learning.exception.IdNotFoundException;
import com.learning.exception.FoodTypeNotFoundException;

public interface FoodService {
	public Food addFood(Food food) throws AlreadyExistsException;
	public Optional<List<Food>> getAllFoodDetails();
	public Food getFoodById(long id) throws IdNotFoundException;
//	public Food getFoodByType(@Valid String foodType) throws FoodTypeNotFoundException;
	public Food updateFood(long id, Food food) throws IdNotFoundException;
	public String deleteFoodById(long id) throws FoodItemNotFoundException;
}