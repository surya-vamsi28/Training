package com.learning.exception;

public class NameNotFoundException extends Exception {
	public NameNotFoundException(String message) {
		super(message);

}
}