package com.learning.service.impl;

import java.util.List;
import java.util.Optional;

//import javax.transaction.Transactional;
import javax.naming.InvalidNameException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;

import com.learning.entity.User;
import com.learning.exception.AlreadyExistsException;
import com.learning.exception.IdNotFoundException;
import com.learning.exception.InvalidEmailException;
import com.learning.exception.InvalidIdLengthException;
import com.learning.exception.InvalidPasswordException;
import com.learning.repo.UserRepository;
import com.learning.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository repository;

	// to add a new user
	@Override
	@org.springframework.transaction.annotation.Transactional(rollbackFor = AlreadyExistsException.class)
	public User addUser(User register) throws AlreadyExistsException {
		if (repository.existsByEmail(register.getEmail()))
			throw new AlreadyExistsException("record already exists");
		User register2 = repository.save(register);
		if (register2 != null) {
			return register2;
		}
		return null;
	}

	// to update the user details
	@Override
	public User updateUser(long id, User user) throws IdNotFoundException {
		try {
			User user2 = getUserById(id);
			if (user2 == null)
				throw new IdNotFoundException("Id Not Found Exception");
			return repository.save(user);
		} catch (IdNotFoundException e) {
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// to get the user details by ID
	@Override
	public User getUserById(long id) throws IdNotFoundException {
		Optional<User> optional = repository.findById(id);
		if (optional.isEmpty())
			throw new IdNotFoundException("ID not found");
		else
			return optional.get();
	}

	// to get all the user details in an array
	@Override
	public User[] getAllUsers()
			throws InvalidIdLengthException, InvalidNameException, InvalidEmailException, InvalidPasswordException {
		List<User> list = repository.findAll();
		User[] array = new User[list.size()];
		return list.toArray(array);
	}

	// to get all the user details in a list
	@Override
	public Optional<List<User>> getAllUserDetails() {
		return Optional.ofNullable(repository.findAll());
	}

	// to delete the user details by ID
	@Override
	public String deleteUserById(long id) throws IdNotFoundException {
		try {
			User optional = getUserById(id);
			if (optional == null) { // if user is not found by id
				throw new IdNotFoundException("record not found");
			} else {
				repository.deleteById(id);
				return "register record deleted";
			}
		} catch (IdNotFoundException e) {
			e.printStackTrace();
			throw new IdNotFoundException(e.getMessage());
			// throw e;
		}
		// catch (Exception e) {
		// e.printStackTrace();
		// return null;
		// }
	}
}
