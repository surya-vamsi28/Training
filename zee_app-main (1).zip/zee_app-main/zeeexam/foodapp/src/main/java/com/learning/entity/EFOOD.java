package com.learning.entity;

public enum EFOOD {
	Indian, Chinese, Mexican;
}