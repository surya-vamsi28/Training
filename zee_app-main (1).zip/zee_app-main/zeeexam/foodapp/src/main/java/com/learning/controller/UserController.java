package com.learning.controller;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.learning.entity.EROLE;
import com.learning.entity.Role;
import com.learning.entity.User;
import com.learning.exception.IdNotFoundException;
import com.learning.payload.request.LoginRequest;
import com.learning.payload.request.SignupRequest;
import com.learning.payload.request.UserDetailsRequest;
import com.learning.payload.response.JwtResponse;
import com.learning.payload.response.MessageResponse;
import com.learning.repo.RoleRepository;
import com.learning.repo.UserRepository;
import com.learning.security.jwt.JwtUtils;
import com.learning.security.services.UserDetailsImpl;
import com.learning.service.UserService;

@CrossOrigin("*")
@RestController
@RequestMapping
public class UserController {

	@Autowired
	UserService userService;

	@Autowired
	UserRepository userRepository;

	@Autowired
	RoleRepository roleRepository;
	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	JwtUtils jwtUtils;

	@Autowired
	AuthenticationManager authenticationManager;

	// to authenticate user using the credentials
	@PostMapping("/api/authenticate")
	public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {
		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));

		SecurityContextHolder.getContext().setAuthentication(authentication);
		String jwt = jwtUtils.generateToken(authentication);
		UserDetailsImpl userDetailsImpl = (UserDetailsImpl) authentication.getPrincipal();

		List<String> roles = userDetailsImpl.getAuthorities().stream().map(i -> i.getAuthority())
				.collect(Collectors.toList());

		return ResponseEntity.ok(new JwtResponse(jwt, userDetailsImpl.getId(), userDetailsImpl.getUsername(),
				userDetailsImpl.getEmail(), roles));
	}

	// to load the user details using token
	// used Post request with request body because the usual method gave errors
    @PreAuthorize("hasRole('ADMIN') || hasRole('USER')")
    @PostMapping("/api/loadUser")
	public ResponseEntity<?> getUserDetails(@RequestBody UserDetailsRequest userDetailsRequest) throws IdNotFoundException {
    	String token = userDetailsRequest.getToken();
		User user = getUserByToken(token);
		return ResponseEntity.ok(user);
	}

	// to signup a new user using the details
	@PostMapping("/api/register")
	public ResponseEntity<?> registerUser(@Valid @RequestBody SignupRequest signupRequest) {
		if (userRepository.existsByEmail(signupRequest.getEmail())) {
			return ResponseEntity.badRequest().body(new MessageResponse("Error: Email is already in use!"));
		}
		if (userRepository.existsByUsername(signupRequest.getUsername())) {
			return ResponseEntity.badRequest().body(new MessageResponse("Error: Username is already taken!"));
		}
		
//		Role role1User = new Role(1, EROLE.ROLE_USER);
//		roleRepository.save(role1User);
//		Role role2Mod = new Role(2, EROLE.ROLE_MODERATOR);
//		roleRepository.save(role2Mod);
//		Role role3Admin = new Role(3, EROLE.ROLE_ADMIN);
//		roleRepository.save(role3Admin);
		
		User user = new User(signupRequest.getUsername(), signupRequest.getEmail(),
				passwordEncoder.encode(signupRequest.getPassword()), signupRequest.getName(),
				signupRequest.getAddress());
		// retrieving the roles details

		Set<String> strRoles = signupRequest.getRole();
		Set<Role> roles = new HashSet<>();
		
		if (strRoles == null || strRoles.isEmpty()) {
			// add a specific email as admin's email
			String adminEmail = "praneeth.01@gmail.com";
			if (signupRequest.getEmail().equals(adminEmail)) {
				Role roleAdmin = roleRepository.findByRoleName(EROLE.ROLE_ADMIN)
						.orElseThrow(() -> new RuntimeException("Error:role not found"));
				roles.add(roleAdmin);
			}
			
			Role userRole = roleRepository.findByRoleName(EROLE.ROLE_USER)
					.orElseThrow(() -> new RuntimeException("Error:role not found"));
			roles.add(userRole);
		}

		else {
			strRoles.forEach(e -> {
				switch (e) {
				case "admin":
					Role roleAdmin = roleRepository.findByRoleName(EROLE.ROLE_ADMIN)
							.orElseThrow(() -> new RuntimeException("Error:role not found"));
					roles.add(roleAdmin);
					break;

				case "mod":
					Role roleMod = roleRepository.findByRoleName(EROLE.ROLE_MODERATOR)
							.orElseThrow(() -> new RuntimeException("Error:role not found"));
					roles.add(roleMod);
					break;
				default:
					Role userRole = roleRepository.findByRoleName(EROLE.ROLE_USER)
							.orElseThrow(() -> new RuntimeException("Error:role not found"));
					roles.add(userRole);
				}
			});
		}
		user.setRoles(roles);
		userRepository.save(user);
//		return ResponseEntity.status(201).body(new MessageResponse("user created successfully"));
		
		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(user.getUsername(), signupRequest.getPassword()));

		SecurityContextHolder.getContext().setAuthentication(authentication);
		String jwt = jwtUtils.generateToken(authentication);
		UserDetailsImpl userDetailsImpl = (UserDetailsImpl) authentication.getPrincipal();

		List<String> roles2 = userDetailsImpl.getAuthorities().stream().map(i -> i.getAuthority())
				.collect(Collectors.toList());

		return ResponseEntity.ok(new JwtResponse(jwt, userDetailsImpl.getId(), userDetailsImpl.getUsername(),
				userDetailsImpl.getEmail(), roles2));
	}

	// To get a user by ID
    @PreAuthorize("hasRole('ADMIN') || hasRole('USER')")
	@GetMapping("/api/users/{id}")
	public ResponseEntity<?> getUserById(@PathVariable("id") int id) throws IdNotFoundException  {
		User result = userService.getUserById(id);
		return ResponseEntity.ok(result);
	}

	// To update a user details
    @PreAuthorize("hasRole('ADMIN') || hasRole('USER')")
	@PutMapping("/api/users/{id}")
	public ResponseEntity<?> updateUser(@PathVariable("id") int id, @RequestBody User register) 
			throws IdNotFoundException	{
		User result = userService.updateUser(id, register);
		return ResponseEntity.ok(result);
	}

	// to delete a user using ID
    @PreAuthorize("hasRole('ADMIN') || hasRole('USER')")
	@DeleteMapping("/api/users/{id}")
	public ResponseEntity<?> deleteUser(@PathVariable("id") int id) throws IdNotFoundException  {
		String result = userService.deleteUserById(id);
		Map<String, String> map = getMessageMap(result);
		return ResponseEntity.ok(map);
	}
    
    public User getUserByToken(String token) throws IdNotFoundException	{
		String username = jwtUtils.getUserNameFromJwtToken(token);
		User user = userRepository.findByUsername(username)
				.orElseThrow(() -> new IdNotFoundException("User not found"));
		return user;
    }

	// create hashmap with a message
	public Map<String, String> getMessageMap(String message)	{
		Map<String, String> map = new HashMap<>();
		map.put("message", message);
		return map;
	}
}
