package com.learning.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.learning.entity.Food;
import com.learning.exception.AlreadyExistsException;
import com.learning.exception.FoodItemNotFoundException;
import com.learning.exception.IdNotFoundException;
import com.learning.repo.FoodRepository;
import com.learning.service.FoodService;

@Service
public class FoodServiceImpl implements FoodService {
	
	@Autowired
	FoodRepository repository;
	
	// add new food
	@Override
	@Transactional(rollbackFor = AlreadyExistsException.class)
	public Food addFood(Food food) throws AlreadyExistsException {
		if (repository.existsByFoodName(food.getFoodName()))
			throw new AlreadyExistsException("record already exists");
		Food food2 = repository.save(food);
		if (food2 != null) {
			return food2;
		}
		return null;
	}

	// to get all food details
	@Override
	public Optional<List<Food>> getAllFoodDetails() {
		return Optional.ofNullable(repository.findAll());
	}

	// to get food details by ID
	@Override
	public Food getFoodById(long id) throws IdNotFoundException {
		Optional<Food> optional = repository.findById(id);
		if (optional.isEmpty())
			throw new IdNotFoundException("ID not found");
		else
			return optional.get();
	}

	// to get food details by type
//	@Override
//	public Food getFoodByType(String type) throws FoodTypeNotFoundException {
//		Food food = repository.findByFoodType(type);
//		if (food == null)
//			throw new FoodTypeNotFoundException("Food type not found");
//		else
//			return food;
//	}

	// to update the food details by ID
	@Override
	public Food updateFood(long id, Food food) throws IdNotFoundException {
		try {
			Food existingFood = getFoodById(id);
			// add new details to existing food
			// foodName, foodCost, foodType, description, foodPic
			if (food.getFoodName() != null)
				existingFood.setFoodName(food.getFoodName());
			if (food.getFoodCost() > 0)
				existingFood.setFoodCost(food.getFoodCost());
			if (food.getFoodType() != null)
				existingFood.setFoodType(food.getFoodType());
			if (food.getDescription() != null)
				existingFood.setDescription(food.getDescription());
			if (food.getFoodPic() != null)
				existingFood.setFoodPic(food.getFoodPic());
			
			Food food2 = repository.save(existingFood);
			if (food2 != null) {
				return food2;
			}
			return null;
		} catch (IdNotFoundException e) {
			throw e;
		}
	}

	// to delete the food details by ID
	@Override
	public String deleteFoodById(long id) throws FoodItemNotFoundException {
		try {
			Food food = getFoodById(id);
			repository.delete(food);
			return "Food deleted successfully";
		} catch (IdNotFoundException e) {
			throw new FoodItemNotFoundException("Sorry. Food item not found");
		}
	}
}