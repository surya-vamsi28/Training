package com.learning.payload.request;

import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class OrderRequest {
    private double orderAmount;
    private long orderTimestamp;
	@NotBlank
	private String token;
}