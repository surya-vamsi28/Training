package com.learning.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.learning.entity.Food;
import com.learning.entity.Order;
import com.learning.entity.User;
import com.learning.exception.AlreadyExistsException;
import com.learning.exception.FoodItemNotFoundException;
import com.learning.exception.FoodTypeNotFoundException;
import com.learning.exception.IdNotFoundException;
import com.learning.payload.request.OrderRequest;
import com.learning.payload.request.UserDetailsRequest;
import com.learning.payload.response.MessageResponse;
import com.learning.repo.FoodRepository;
import com.learning.repo.OrderRepository;
import com.learning.repo.UserRepository;
import com.learning.security.jwt.JwtUtils;
import com.learning.service.FoodService;

@CrossOrigin("*")
@RestController
@RequestMapping
public class FoodController {
    @Autowired
    FoodService foodService;
    
    @Autowired
    FoodRepository foodRepository;
    
    @Autowired
    OrderRepository orderRepository;
    
	@Autowired
	JwtUtils jwtUtils;

	@Autowired
	UserRepository userRepository;

    // to add a new food
    @PreAuthorize("hasRole('ADMIN')")  // works if logged in as admin
    @PostMapping("/api/food")
    public ResponseEntity<?> addFood(@Valid @RequestBody Food food) throws AlreadyExistsException {
        Food result = foodService.addFood(food);
        return ResponseEntity.status(201).body(result);
    }

	// To get a food by ID
    @PreAuthorize("hasRole('ADMIN')")  // works if logged in as admin
    @GetMapping("/api/food/{foodID}")
    public ResponseEntity<?> getFoodById(@Valid @PathVariable("foodID") long foodID) throws IdNotFoundException {
        Food result = foodService.getFoodById(foodID);
        return ResponseEntity.status(HttpStatus.OK).body(result);
    }

	// To get a food by type
    @PreAuthorize("hasRole('ADMIN')")  // works if logged in as admin
    @GetMapping("/api/food/type/{foodType}")
    public ResponseEntity<?> getFoodByType(@Valid @PathVariable("foodType") String foodType) throws FoodTypeNotFoundException {
        try {
        	// foodRepository.findByFoodType(foodType);
        	Optional<List<Food>> optional = foodService.getAllFoodDetails();
        	// if the list is empty
            if (optional.isEmpty()) {
                Map<String, String> map = getMessageMap("No data found");
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body(map);
            }
            List<Food> foodList = optional.get();
            // Code tested and working. Submitted in the last exam
            // add from foodList matching the given foodType
            List<Food> result = new ArrayList<Food>();
            for (Food food: foodList)
            	if (food.getFoodType().toString().equals(foodType))
					result.add(food);
        	return ResponseEntity.status(HttpStatus.OK).body(result);
//            return ResponseEntity.status(HttpStatus.OK).body(foodList);
        } catch (Exception e) {
        	e.printStackTrace();
			throw new FoodTypeNotFoundException("Food type " + foodType + " is not found");
		}
    }

	// To update food details
    @PreAuthorize("hasRole('ADMIN')")  // works if logged in as admin
    @PutMapping("/api/food/{foodID}")
    public ResponseEntity<?> updateFood(@Valid @PathVariable("foodID") long id, @RequestBody Food food) throws IdNotFoundException {
        Food result = foodService.updateFood(id, food);
        return ResponseEntity.ok(result);
    }

	// To get all food details
    @PreAuthorize("hasRole('ADMIN') || hasRole('USER')")  // works if logged in as admin
    @GetMapping("/api/food")
    public ResponseEntity<?> getAllFoodDetails() {
        Optional<List<Food>> optional = foodService.getAllFoodDetails();
    	// if the list is empty
        if (optional.isEmpty()) {
            Map<String, String> map = getMessageMap("No data found");
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(map);
        }
        return ResponseEntity.ok(optional.get());
    }

	// To delete a food by ID
    @PreAuthorize("hasRole('ADMIN')")  // works if logged in as admin
    @DeleteMapping("/api/food/{foodID}")
    public ResponseEntity<?> deleteFoodById(@PathVariable("foodID") long id) throws FoodItemNotFoundException  {
        String result = foodService.deleteFoodById(id);
        Map<String, String> map = getMessageMap(result);
        return ResponseEntity.ok(map);
    }

    @PreAuthorize("hasRole('USER')")
    @PostMapping("/api/food/order")
    public ResponseEntity<?> createOrder(@RequestBody OrderRequest orderRequest) {
    	String token = orderRequest.getToken();
    	User user;
    	try {
			user = getUserByToken(token);
		} catch (IdNotFoundException e) {
			return ResponseEntity.badRequest().body(new MessageResponse("Error: Token not found"));
		}
        Order order = new Order(orderRequest.getOrderAmount(),
            orderRequest.getOrderTimestamp(), user.getId());
        Order order2 = orderRepository.save(order);
        if (order2 != null) {
            return ResponseEntity.ok(order2);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PreAuthorize("hasRole('USER')")
    @PostMapping("/api/food/orderhistory")
    public ResponseEntity<?> getAllOrders(@RequestBody UserDetailsRequest userDetailsRequest) {
    	String token = userDetailsRequest.getToken();
    	User user;
    	try {
			user = getUserByToken(token);
		} catch (IdNotFoundException e) {
			return ResponseEntity.badRequest().body(new MessageResponse("Error: Token not found"));
		}

    	Optional<List<Order>> optional = orderRepository.findByUserId(user.getId());
        if (optional.isEmpty() || optional.get().isEmpty()) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        }
        return ResponseEntity.ok(optional.get());
    }
    
    public User getUserByToken(String token) throws IdNotFoundException	{
		String username = jwtUtils.getUserNameFromJwtToken(token);
		User user = userRepository.findByUsername(username)
				.orElseThrow(() -> new IdNotFoundException("User not found"));
		return user;
    }

	// create hashmap with a message
	public Map<String, String> getMessageMap(String message)	{
		Map<String, String> map = new HashMap<>();
		map.put("message", message);
		return map;
	}
}

/*
sample data to add foods
{
    "foodName": "Pizza",
    "foodCost": 100,
    "foodType": "Mexican",
    "description": "Pizza is a dish of Italian origin consisting of a usually round, flat base of leavened wheat-based dough topped with tomatoes",
    "foodPic": "https://cdn.britannica.com/08/177308-050-94D9D6BE/Food-Pizza-Basil-Tomato.jpg"
}
{
    "foodName": "Burger",
    "foodCost": 120,
    "foodType": "Chinese",
    "description": "These burgers may be made from ingredients like beans, especially soybeans and tofu, nuts, grains, seeds or fungi such as mushrooms or mycoprotein.",
    "foodPic": "https://mfacdn.cachefly.net/chooseveg/sites/2/2018/11/Best-Vegan-Burgers.jpeg"
}
{
    "foodName": "Mushroom Manchuria",
    "foodCost": 150,
    "foodType": "Indian",
    "description": "Manchurian Mushroom also popularly known as the Mushroom Chilli is an Indian Chinese dish which can be prepared in just less than 10 minutes",
    "foodPic": "https://th.bing.com/th/id/OIP.q25AUERk2yt1jj5MG4xlXwHaEx?pid=ImgDet&rs=1"
}
{
    "foodName": "Samosa",
    "foodCost": 80,
    "foodType": "Indian",
    "description": "A samosa is a fried or baked pastry with a savory filling, including ingredients such as spiced potatoes, onions, or peas.",
    "foodPic": "https://curlytales.com/wp-content/uploads/2019/11/Samosa-Recipe.jpg"
}

{
    "foodName": "Green Tea",
    "foodCost": 50,
    "foodType": "Chinese",
    "description": "Green tea is a type of tea that is made from Camellia sinensis leaves, which are used to make the leaves into a beverage.",
    "foodPic": "http://www.mydiabeteslifestyle.com/wp-content/uploads/2020/05/green_tea.jpeg"
}

{
    "foodName": "Green Salad",
    "foodCost": 30,
    "foodType": "Mexican",
    "description": "Green salad is a salad made from fresh, leafy vegetables, such as lettuce, cabbage, and/or kale, and often containing other ingredients such as fruit, nuts, and/or cheese.",
    "foodPic": "https://www.dinnersbydelaine.com/wp-content/uploads/2019/11/Chopped-Green-Salad1.jpg"
}

{
    "foodName": "Tofu salad",
    "foodCost": 40,
    "foodType": "Mexican",
    "description": "Tofu salad is a salad made from tofu, usually served with a variety of vegetables, often including fruit, and often containing other ingredients such as cheese, nuts, and/or dressing.",
    "foodPic": "https://images.media-allrecipes.com/userphotos/960x960/4727256.jpg"
}

{
    "foodName": "Tomato soup",
    "foodCost": 60,
    "foodType": "Indian",
    "description": "Tomato soup is a soup made from tomatoes, often with a variety of vegetables, often including fruit, and often containing other ingredients such as cheese, nuts, and/or dressing.",
    "foodPic": "https://bigoven-res.cloudinary.com/image/upload/creamy-tomato-soup-4.jpg"
}

{
    "foodName": "Veg noodles",
    "foodCost": 70,
    "foodType": "Chinese",
    "description": "Veg noodles are a type of noodle dish made from vegetables, often including vegetables such as cabbage, carrots, and/or broccoli.",
    "foodPic": "https://thechutneylife.com/wp-content/uploads/2017/09/Veg-Hakka-Noodles-The-Chutney-Life-9-300x200.jpg"
}

{
    "foodName": "French fries",
    "foodCost": 80,
    "foodType": "Indian",
    "description": "French fries are a type of food made from potatoes, often with a variety of vegetables, often including fruit, and often containing other ingredients such as cheese, nuts, and/or dressing.",
    "foodPic": "https://s23991.pcdn.co/wp-content/uploads/2020/06/perfect-french-fries-fp.jpg.optimal.jpg"
}

*/