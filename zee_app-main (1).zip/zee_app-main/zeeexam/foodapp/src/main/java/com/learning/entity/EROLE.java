package com.learning.entity;

public enum EROLE {
	ROLE_USER,
	ROLE_ADMIN,
	ROLE_MODERATOR;
}
