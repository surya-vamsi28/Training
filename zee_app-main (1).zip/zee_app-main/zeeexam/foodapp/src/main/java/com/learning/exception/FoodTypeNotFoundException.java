package com.learning.exception;

import lombok.ToString;

@ToString(callSuper = true)
public class FoodTypeNotFoundException extends Exception {
	String type = "";
	public FoodTypeNotFoundException(String message) {
		super(message);
	}
	public FoodTypeNotFoundException(String message, String type) {
		super(message);
		this.type = type;
	}
}