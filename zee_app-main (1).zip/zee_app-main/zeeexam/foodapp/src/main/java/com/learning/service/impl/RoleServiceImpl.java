package com.learning.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.learning.entity.Role;
import com.learning.exception.IdNotFoundException;
import com.learning.repo.RoleRepository;
import com.learning.service.RoleService;

@Service
public class RoleServiceImpl implements RoleService {
    @Autowired
    RoleRepository repository;
    
    // to add a new role
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String addRole(Role role) {
        Role role2 = repository.save(role);
        if (role2 != null)
            return "success";
        else
            return "Failed";
    }

    // to update the role details
    @Override
    public String updateRole(int id, Role role) {
        return addRole(role);
    }

    // to get the role details by ID
    @Override
    public Optional<Role> getRoleById(int id) {
        return repository.findById(id);
    }

    // to get all the role details in an array
    @Override
    public Role[] getAllRoles() {
        List<Role> roles = repository.findAll();
        Role[] roles2 = new Role[roles.size()];
        return roles.toArray(roles2);
    }

    // to get all the roles details in a list
    @Override
    public List<Role> getAllRoleDetails() {
        return repository.findAll();
    }

    // to delete the role details by ID
    @Override
    public String deleteRoleById(int id) throws IdNotFoundException {
		try {
			Optional<Role> optional = getRoleById(id);
			if(optional.isEmpty()) {
				throw new IdNotFoundException("record not found");
			}
			else {
				repository.deleteById(id);
				return "success";
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new IdNotFoundException(e.getMessage());
		}
    }
}