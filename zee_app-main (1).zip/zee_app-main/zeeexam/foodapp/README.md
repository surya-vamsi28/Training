# Screenshots

Exam-2 screenshots are in images2/ directory

For exam-1,
Postman screenshots are in images/postman/ directory.
DB screenshots are in images/db/ directory

Postman collection is in the current directory. (See above)
