package com.zee.zee5app.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zee.zee5app.dto.Movie;
import com.zee.zee5app.exception.AlreadyExistsException;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.repository.MovieRepository;
import com.zee.zee5app.service.MovieService;

@Service
public class MovieServiceImpl implements MovieService {

	@Autowired
	MovieRepository repository;
	
	@Override
	public Movie addMovie(Movie movie) throws AlreadyExistsException {
		if (repository.existsByMovieName(movie.getMovieName()))
			throw new AlreadyExistsException("record already exists");
		Movie movie2 = repository.save(movie);
		if (movie2 != null)
			return movie2;
		return null;
	}

	@Override
	public Optional<List<Movie>> getMovies() {
		return Optional.ofNullable(repository.findAll());
	}

	@Override
	public Optional<Movie> getMovieById(long id) throws IdNotFoundException {
		return repository.findById(id);
	}

	@Override
	public String deleteMovieById(long id) throws IdNotFoundException {
		try {
			Optional<Movie> optional = this.getMovieById(id);
			if (optional.isEmpty())
				throw new IdNotFoundException("record not found");
			else {
				repository.deleteById(id);
				return "success";
			}
		} catch (IdNotFoundException e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public String modifyMovieById(long id, Movie movie) throws IdNotFoundException {
		try {
			Optional<Movie> optional = getMovieById(id);
			if (optional.isEmpty())
				throw new IdNotFoundException("record not found");
			else {
				repository.save(movie);
				return "success";
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new IdNotFoundException(e.getMessage());
		}
	}

}
