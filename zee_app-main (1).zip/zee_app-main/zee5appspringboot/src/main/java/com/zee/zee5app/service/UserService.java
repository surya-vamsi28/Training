package com.zee.zee5app.service;

import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import com.zee.zee5app.dto.User;
import com.zee.zee5app.exception.AlreadyExistsException;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.exception.InvalidEmailException;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidPasswordException;

public interface UserService {
	public User addUser(User register) throws AlreadyExistsException;
	public String updateUser(long id, User register) throws IdNotFoundException;
	public User getUserById(long id) throws IdNotFoundException;
	public User[] getAllUsers() throws InvalidNameException, InvalidIdLengthException, InvalidEmailException, InvalidPasswordException ;
	public String deleteUserById(long id) throws IdNotFoundException;
	public Optional<List<User>> getAllUserDetails();
}
