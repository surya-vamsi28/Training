package com.zee.zee5app.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zee.zee5app.dto.Episode;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.repository.EpisodeRepository;
import com.zee.zee5app.service.EpisodeService;

@Service
public class EpisodeServiceImpl implements EpisodeService {
	@Autowired
	EpisodeRepository repository;
	
	@Override
	public Episode addEpisode(Episode episode) {
		Episode episode2 = repository.save(episode);
		if(episode2 != null) {
			return episode2;
		}
		else {
			return null;
		}
	}

	@Override
	public Optional<List<Episode>> getEpisodes() {
		return Optional.ofNullable(repository.findAll());
	}

	@Override
	public Optional<Episode> getEpisodeById(Long id) {
		return repository.findByEpiId(id);
	}

	@Override
	public String deleteEpisodeById(Long id) throws IdNotFoundException {
		try {
			Optional<Episode> optional = getEpisodeById(id);
			if (optional.isEmpty()) {
				throw new IdNotFoundException("record not found");
			}
			else {
				repository.deleteByEpiId(id);
				return "success";
			}
		} catch (IdNotFoundException e) {
			e.printStackTrace();
			throw new IdNotFoundException(e.getMessage());
		}
	}

	@Override
	public Episode modifyEpisodeById(Long id, Episode episode) throws IdNotFoundException {
		try {
			Optional<Episode> optional = getEpisodeById(id);
			if (optional.isEmpty()) {
				throw new IdNotFoundException("record not found");
			}
			else {
				return repository.save(episode);
			}
		} catch (IdNotFoundException e) {
			e.printStackTrace();
			throw new IdNotFoundException(e.getMessage());
		}
	}

}
