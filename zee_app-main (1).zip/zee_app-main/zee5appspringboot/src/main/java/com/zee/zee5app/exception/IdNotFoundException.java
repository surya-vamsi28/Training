package com.zee.zee5app.exception;

public class IdNotFoundException extends Exception {
	public IdNotFoundException(String message) {
		super(message);
	}

}
