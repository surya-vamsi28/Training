package com.zee.zee5app.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zee.zee5app.dto.Subscription;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.repository.SubscriptionRepository;
import com.zee.zee5app.service.SubscriptionService;

@Service
public class SubscriptionServiceImpl implements SubscriptionService {
	
	@Autowired
	SubscriptionRepository repository;
	
	@Override
	public Subscription addSubscription(Subscription subscription) {
		Subscription subscription2 = repository.save(subscription);
		if(subscription2 != null) {
			return subscription2;
		}
		else {
			return null;
		}
	}

	@Override
	public Optional<List<Subscription>> getSubscriptions() {
		return Optional.ofNullable(repository.findAll());
	}

	@Override
	public Optional<Subscription> getSubscriptionById(Long id) throws IdNotFoundException {
		return repository.findBySubId(id);
	}

	@Override
	public String deleteSubscriptionById(Long id) throws IdNotFoundException {
		try {
			Optional<Subscription> optional = this.getSubscriptionById(id);
			if(optional.isEmpty()) {
				throw new IdNotFoundException("record not found");
			}
			else {
				repository.deleteBySubId(id);
				return "success";
			}
		} catch (IdNotFoundException e) {
			e.printStackTrace();
			throw new IdNotFoundException(e.getMessage());
		}
	}

	@Override
	public Subscription modifySubscriptionById(Long id, Subscription subscription) throws IdNotFoundException  {
		try {
			Optional<Subscription> optional = this.getSubscriptionById(id);
			if(optional.isEmpty()) {
				throw new IdNotFoundException("record not found");
			}
			else {
				return repository.save(subscription);
			}
		} catch (IdNotFoundException e) {
			e.printStackTrace();
			throw new IdNotFoundException(e.getMessage());
		}
	}

}
