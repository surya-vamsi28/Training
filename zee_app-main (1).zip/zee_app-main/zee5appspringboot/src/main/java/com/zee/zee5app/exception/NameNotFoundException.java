package com.zee.zee5app.exception;

public class NameNotFoundException extends Exception {
	public NameNotFoundException(String message) {
		super(message);

}
}