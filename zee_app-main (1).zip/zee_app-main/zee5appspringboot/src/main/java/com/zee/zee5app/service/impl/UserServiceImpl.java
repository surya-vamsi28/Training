package com.zee.zee5app.service.impl;

import java.util.List;
import java.util.Optional;

//import javax.transaction.Transactional;
import javax.naming.InvalidNameException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;

import com.zee.zee5app.dto.User;
import com.zee.zee5app.exception.AlreadyExistsException;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.exception.InvalidEmailException;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidPasswordException;
import com.zee.zee5app.repository.UserRepository;
import com.zee.zee5app.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository repository;
	@Autowired
	LoginServiceImpl loginService;
	
	@Override
	@org.springframework.transaction.annotation.Transactional(rollbackFor = AlreadyExistsException.class)
	public User addUser(User register) throws AlreadyExistsException {
		if (repository.existsByEmail(register.getEmail()))
			throw new AlreadyExistsException("record already exists");
		User register2 = repository.save(register);
		if (register2 != null) {
			// Login login = new Login(register.getEmail(), register.getPassword(),
			// 		register.getId(), EROLE.ROLE_USER, register2);
			// if (loginRepository.existsByUsername(register.getEmail()))
			// 	throw new AlreadyExistsException("record exists");
			// String res = loginService.addCredentials(login);
			return register2;
		}
		return null;
	}

	@Override
	public String updateUser(long id, User register) throws IdNotFoundException {
		try {
			User user = getUserById(id);
			if (user == null)
				throw new IdNotFoundException("Id Not Found Exception");
			repository.save(register);
			return "success";
		} catch (IdNotFoundException e) {
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public User getUserById(long id)
				throws IdNotFoundException {
		Optional<User> optional = repository.findById(id);
		if (optional.isEmpty())
			throw new IdNotFoundException("ID not found");
		else
			return optional.get();
	}

	@Override
	public User[] getAllUsers()
			throws InvalidIdLengthException, InvalidNameException,
			InvalidEmailException, InvalidPasswordException {
		List<User> list = repository.findAll();
		User[] array = new User[list.size()];
		return list.toArray(array);
	}

	@Override
	public Optional<List<User>> getAllUserDetails()  {
		return Optional.ofNullable(repository.findAll());
	}

	@Override
	public String deleteUserById(long id) throws IdNotFoundException {
		try {
			User optional = getUserById(id);
			if(optional==null) {
				throw new IdNotFoundException("record not found");
			}
			else {
				repository.deleteById(id);
				return "register record deleted";
			}
		} catch (IdNotFoundException e) {
			e.printStackTrace();
			throw new IdNotFoundException(e.getMessage());
			// throw e;
		}
		// catch (Exception e) {
		// 	e.printStackTrace();
		// 	return null;
		// }
	}
}
