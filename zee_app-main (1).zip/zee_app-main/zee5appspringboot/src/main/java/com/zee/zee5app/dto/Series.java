package com.zee.zee5app.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@NoArgsConstructor
@Setter
@ToString
@AllArgsConstructor
@Entity
@Table(name = "series",
	uniqueConstraints = {@UniqueConstraint(columnNames = "seriesName")})
public class Series implements Comparable<Series> {
	@Id
	@Column(name = "seriesId")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@NotBlank
	private String seriesName;
	@Max(value = 70)
	private int agelimit;
	@NotBlank
	private String cast; // separated by comma
	@NotBlank
	private String genre;
//	@NotBlank
//	private String trailer;
	@Lob
	private byte[] trailer;
	@NotNull
	private Date releaseDate;
	@NotBlank
	private String language;
	@Min(value=1)
	private int noOfEpisodes;
	
	@Override
	public int compareTo(Series other) {
		return this.id.compareTo(other.id);
	}
	
	@OneToMany(mappedBy = "series", cascade=CascadeType.ALL, fetch=FetchType.LAZY) //series is name of foreign key
	@JsonProperty(access=Access.WRITE_ONLY)
	private List<Episode> episodes = new ArrayList<>();

	public Series(String seriesName, int agelimit, String cast, String genre, byte[] trailer, Date releaseDate,
			String language, int noOfEpisodes) {
		super();
		this.seriesName = seriesName;
		this.agelimit = agelimit;
		this.cast = cast;
		this.genre = genre;
		this.trailer = trailer;
		this.releaseDate = releaseDate;
		this.language = language;
		this.noOfEpisodes = noOfEpisodes;
	}
}
