package com.zee.zee5app.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zee.zee5app.dto.Login;
import com.zee.zee5app.dto.EROLE;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.repository.LoginRepository;
import com.zee.zee5app.service.LoginService;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	LoginRepository repository;
	@Override
	public String addCredentials(Login login) {
		Login login2 = repository.save(login);
		if(login2 != null) {
			return "success";
		}
		else {
			return "fail";
		}
	}

	@Override
	public String deleteCredentials(String username) throws IdNotFoundException {
		try {
			Optional<Login> optional = repository.findById(username);
			if(optional.isEmpty()) {
				throw new IdNotFoundException("record not found");
			}
			else {
				repository.deleteById(username);
				return "success";
			}
		} catch (IdNotFoundException e) {
			e.printStackTrace();
			throw new IdNotFoundException(e.getMessage());
		}
	}
	
	@Override
	public Login getCredentialsByUsername(String username) throws IdNotFoundException {
		try {
			Optional<Login> optional = repository.findById(username);
			if(optional.isEmpty()) {
				throw new IdNotFoundException("record not found");
			}
			else {
				return optional.get();
			}
		} catch (IdNotFoundException e) {
			e.printStackTrace();
			throw new IdNotFoundException(e.getMessage());
		}
	}

	@Override
	public String changePassword(String username, String password) {
		Login login;
		try {
			login = getCredentialsByUsername(username);
			login.setPassword(password);
			repository.save(login);
			return "success";
		} catch (IdNotFoundException e) {
			e.printStackTrace();
			return "Error: " + e.toString();
		}
	}

	@Override
	public String changeRole(String username, EROLE role) {
		return null;
	}

}
