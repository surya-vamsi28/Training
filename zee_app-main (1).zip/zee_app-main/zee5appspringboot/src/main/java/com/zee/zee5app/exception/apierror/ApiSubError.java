package com.zee.zee5app.exception.apierror;

public abstract class ApiSubError {

}
