package com.zee.zee5app.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "episode",
	uniqueConstraints = {@UniqueConstraint (columnNames = "episodename")})
public class Episode {
    @Id
    @Column(name = "epiId")
	@GeneratedValue(strategy = GenerationType.AUTO)
    private Long epiId;
//    @NotBlank
//    private String seriesId;
    @NotBlank
    private String episodeName;
    @NotNull
    private int epiLength;
    @NotBlank
    private String location;
//    @NotBlank
    private byte[] trailer;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="seriesId")
//	@JsonProperty(access=Access.WRITE_ONLY)
	@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
	private Series series;

    // constructor with series
    public Episode(String episodeName, int epiLength, String location, byte[] trailer, Series series) {
        super();
        this.episodeName = episodeName;
        this.epiLength = epiLength;
        this.location = location;
        this.trailer = trailer;
        this.series = series;
    }

    // constructor without series
    public Episode(String episodeName, int epiLength, String location, byte[] trailer) {
        super();
        this.episodeName = episodeName;
        this.epiLength = epiLength;
        this.location = location;
        this.trailer = trailer;
    }
}