package com.zee.zee5app.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zee.zee5app.dto.Series;
import com.zee.zee5app.exception.AlreadyExistsException;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.repository.SeriesRepository;
import com.zee.zee5app.service.SeriesService;

@Service
public class SeriesServiceImpl implements SeriesService {
	@Autowired
	SeriesRepository repository;
	
	@Override
	public Series addSeries(Series series) throws AlreadyExistsException {
		Series series2 = repository.save(series);
		if (series2 != null)
			return series2;
		else
			throw new AlreadyExistsException("already exists");
	}

	@Override
	public Optional<List<Series>> getSeries() {
		return Optional.ofNullable(repository.findAll());
	}

	@Override
	public Optional<Series> getSeriesById(long id) throws IdNotFoundException {
		return repository.findById(id);
	}

	@Override
	public String modifySeriesById(long id, Series series) throws IdNotFoundException {
		try {
			Optional<Series> optional = repository.findById(id);
			if (optional.isEmpty())
				throw new IdNotFoundException("No such id found");
			repository.save(series);
			return "successfully modified series";
		} catch (IdNotFoundException e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public String deleteSeriesById(long id) throws IdNotFoundException {
		try {
			Optional<Series> optional = getSeriesById(id);
			if(optional.isEmpty())
				throw new IdNotFoundException("record not found");
			else {
				repository.deleteById(id);
				return "success";
			}
		} catch (IdNotFoundException e) {
			e.printStackTrace();
			throw e;
		}
	}
}
