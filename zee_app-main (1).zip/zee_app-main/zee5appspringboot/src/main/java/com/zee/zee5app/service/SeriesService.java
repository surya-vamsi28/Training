package com.zee.zee5app.service;

import java.util.List;
import java.util.Optional;

import com.zee.zee5app.dto.Series;
import com.zee.zee5app.exception.AlreadyExistsException;
import com.zee.zee5app.exception.IdNotFoundException;

public interface SeriesService {
	public Series addSeries(Series series) throws AlreadyExistsException;
	public Optional<List<Series>> getSeries();
	public Optional<Series> getSeriesById(long id) throws IdNotFoundException;
	public String deleteSeriesById(long id) throws IdNotFoundException;
	public String modifySeriesById(long id, Series series) throws IdNotFoundException;
}
