package com.zee.zee5app.service;

import java.util.List;
import java.util.Optional;

import com.zee.zee5app.dto.Subscription;
import com.zee.zee5app.exception.IdNotFoundException;

public interface SubscriptionService {
	public Subscription addSubscription(Subscription subscription);
	public Optional<List<Subscription>> getSubscriptions();
	public Optional<Subscription> getSubscriptionById(Long id) throws IdNotFoundException;
	public String deleteSubscriptionById(Long id) throws IdNotFoundException;
	public Subscription modifySubscriptionById(Long id, Subscription subscription) throws IdNotFoundException;
}
