package com.zee.zee5app.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zee.zee5app.dto.Movie;
import com.zee.zee5app.exception.AlreadyExistsException;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.service.MovieService;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/movies")
public class MovieController {
	@Autowired
	MovieService movieService;
	
	@PostMapping("/addMovie")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ResponseEntity<?> addMovie(@Valid @RequestBody Movie movie) throws AlreadyExistsException	{
		Movie result = movieService.addMovie(movie);
		return ResponseEntity.status(201).body(result);
	}

	@GetMapping("/{id}")
	@PreAuthorize("hasRole('ROLE_USER') || hasRole('ROLE_ADMIN')")
	public ResponseEntity<?> getMovieById(@PathVariable("id") long id) throws IdNotFoundException {
		Optional<Movie> movieDetails = movieService.getMovieById(id);
		return ResponseEntity.status(200).body(movieDetails.get());
	}

	// get all movies
	@GetMapping("/all")
	@PreAuthorize("hasRole('ROLE_USER') || hasRole('ROLE_ADMIN')")
	public ResponseEntity<?> getAllMovies() {
		Optional<List<Movie>> optional = movieService.getMovies();
		if (optional.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No movies found");
		}
		return ResponseEntity.status(200).body(optional.get());	
	}
}
/* test addMovie
{
	"movieName": "Parasite",
	"ageLimit": 18,
	"cast": "Bong Joon-ho, Lee Sun-kyun, Jung Kook-won, Son Hee-ryong",
	"genre": "Drama",
	"length": 120,
	"releaseDate": "05/05/2019",
	"language": "Korean"
}
*/