package com.zee.zee5app.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Data
@NoArgsConstructor
@ToString
@Entity
@Table(name = "movie")
public class Movie {
	@Id
	@Column(name = "movId")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@NotBlank
	private String movieName;
	
	@Max(value = 70)
	private int ageLimit;
	
	@NotBlank
	private String cast;
	
	@NotBlank
	private String genre;
	
	@Min(value = 1)
	private int length;

//	@NotBlank
//	private String trailer;
	
	@Lob
	private byte[] trailer;
	
	@NotBlank
	private String releaseDate;
	
	@NotBlank
	private String language;

	public Movie(String movieName, int ageLimit, String cast, String genre, int length, byte[] trailer,
			String releaseDate, String language) {
		super();
		this.movieName = movieName;
		this.ageLimit = ageLimit;
		this.cast = cast;
		this.genre = genre;
		this.length = length;
		this.trailer = trailer;
		this.releaseDate = releaseDate;
		this.language = language;
	}
}
