package com.zee.zee5app.service;

import java.util.List;
import java.util.Optional;

import com.zee.zee5app.dto.Movie;
import com.zee.zee5app.exception.AlreadyExistsException;
import com.zee.zee5app.exception.IdNotFoundException;

public interface MovieService {
	public Movie addMovie(Movie movie) throws AlreadyExistsException;
	public Optional<List<Movie>> getMovies();
	public Optional<Movie> getMovieById(long id) throws IdNotFoundException;
	public String deleteMovieById(long id) throws IdNotFoundException;
	public String modifyMovieById(long id, Movie movie) throws IdNotFoundException;
}
