package com.zee.zee5app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class Zee5appspringbootApplication {
	public static void main(String[] args) {		
		ConfigurableApplicationContext applicationContext = 
				SpringApplication.run(Zee5appspringbootApplication.class, args);
//		DataSource dataSource = applicationContext.getBean(DataSource.class);
//		System.out.println("dataSource != null: " + (dataSource != null));
//
//		UserService userService = applicationContext.getBean(UserServiceImpl.class);
//		LoginService loginService = applicationContext.getBean(LoginServiceImpl.class);
		
//		User register = null;
//		String res = null;
//		try {
//			register = new Register("ab00001", "Praneeth", "Vadlapati",
//									"pr00001@email.com",
//									"test12345", new BigDecimal("1234567890"), null);
//			res = userService.addUser(register);
//			System.out.println("addUser: " + res);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}

		// add same user to Login table
//		Login login = new Login(register.getEmail(), register.getPassword(),
//				register.getId(), ROLE.ROLE_USER);
//
//		// change password
//		login.setPassword("test123456");  // new password
//		
//		res = loginService.changePassword(login.getUsername(), login.getPassword());
//		System.out.println("changePassword: " + res);
//
//		// change role
//		login.setRole(ROLE.ROLE_ADMIN);
//		res = loginService.changeRole(login.getUsername(), login.getRole());
//		System.out.println("loginService: " + res);
//		
		// delete
//		try {
//			res = userService.deleteUserById("ab00001");
//			System.out.println("deleteUserById: " + res);
//		} catch (IdNotFoundException e) {
//			e.printStackTrace();
//		}

//		applicationContext.close();
	}
}
