package com.zee.zee5app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.zee.zee5app.exception.AlreadyExistsException;

@SpringBootApplication
public class Main2 {
	public static void main(String[] args) throws AlreadyExistsException {
		ConfigurableApplicationContext applicationContext = SpringApplication.run(
				Zee5appspringbootApplication.class, args);
		
//		RoleService roleService = applicationContext.getBean(RoleService.class);
//		Role role = new Role();
//		role.setRoleName(EROLE.ROLE_ADMIN);
//		System.out.println(roleService.addRole(role));
//		
//		Role role2 = new Role();
//		role2.setRoleName(EROLE.ROLE_USER); 
//		System.out.println(roleService.addRole(role2));
//		
//		RoleRepository roleRepository = applicationContext.getBean(RoleRepository.class);
//		UserService userService = applicationContext.getBean(UserService.class);
//		Register register;
//		register = new Register("ab000008", "praneeth", "V", "praneeth.v@gmail.com",
//				"Ji2ed3443", null, null, null);  //, null)
//		register.setContactNumber(new BigDecimal("9813973123"));
//		Set<Role> roles = new HashSet<>();
//		roles.add(roleRepository.findById(1).get());
//		register.setRoles(roles);
//		try {
//			userService.deleteUserById("ab000008");
//		} catch (IdNotFoundException e) {
//			e.printStackTrace();
//		}
//		System.out.println(userService.addUser(register));
//		
//		SubscriptionService subscriptionService = applicationContext.getBean(SubscriptionService.class);
//		
//		Subscription subscription = new Subscription(
//			"sub001", "2018", "2019", 499, "CREDITCARD", "Success",
//			"False", "False", register);
//		System.out.println(subscriptionService.addSubscription(subscription));
//		
//		SeriesService seriesService = applicationContext.getBean(SeriesService.class);
//		EpisodeService episodeService = applicationContext.getBean(EpisodeService.class);
//		Series series1 = new Series("SER001", "Mirzapur", 18, "Vikram",
//					"action", null, 
//					new Date("2018-01-01"), "Hindi", 9, null);
//		System.out.println(seriesService.addSeries(series1));
//		
//		Episode episode = new Episode("Ep001", "SER001", "Blablabla", 45, null, 
//				null, series1);
//		System.out.println(episodeService.addEpisode(episode));
//		
//		MovieService movieService = applicationContext.getBean(MovieService.class);
//		Movie movie = new Movie();
//		movie.setId("mov001");
//		movie.setMovieName("pushpa");
//		movie.setAgeLimit(18);
//		movie.setCast("Allu Arjun");
//		movie.setGenre("abc");
//		movie.setLength(250);
//		movie.setReleaseDate("2021-01-01");
//		movie.setLanguage("hindi");
//		movie.setTrailer(readFile());
//		System.out.println(movieService.addMovie(movie));
//		writeToFile(movie.getTrailer());
		
//		FileUtils fileUtils = applicationContext.getBean(FileUtils.class);
//		File fileIn = new File("D:\\video_small.mp4");
//		String fileNameOut = "D:\\video_output\\video_small.mp4";
//		
//		SeriesService seriesService = applicationContext.getBean(SeriesService.class);
//		Series series1 = new Series();
//		series1.setId("SER001");
//		series1.setSeriesName("Mirzapur");
//		series1.setAgelimit(18);
//		series1.setCast("Vikram");
//		series1.setGenre("action");
//		try {
//			series1.setTrailer(fileUtils.readFile(fileIn));
//		} catch (IOException e) {
//			System.out.println("Error: " + e.getClass());
//		}
//		series1.setReleaseDate(new Date());
//		series1.setLanguage("Hindi");
//		series1.setNoOfEpisodes(9);
//		System.out.println(seriesService.addSeries(series1));
		
//		try {
//			fileUtils.writeToFile(fileNameOut, series1.getTrailer());
//		} catch (IOException e) {
//			System.out.println("Error: " + e.getClass());
//		}

//		applicationContext.close();
	}
}
