package com.zee.zee5app.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zee.zee5app.dto.Role;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.repository.RoleRepository;
import com.zee.zee5app.service.RoleService;

@Service
public class RoleServiceImpl implements RoleService {
    @Autowired
    RoleRepository repository;
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String addRole(Role role) {
        Role role2 = repository.save(role);
        if (role2 != null)
            return "success";
        else
            return "Failed";
    }

    @Override
    public String updateRole(int id, Role role) {
        return addRole(role);
    }

    @Override
    public Optional<Role> getRoleById(int id) {
        return repository.findById(id);
    }

    @Override
    public Role[] getAllRoles() {
        List<Role> roles = repository.findAll();
        Role[] roles2 = new Role[roles.size()];
        return roles.toArray(roles2);
    }

    @Override
    public List<Role> getAllRoleDetails() {
        return repository.findAll();
    }

    @Override
    public String deleteRoleById(int id) throws IdNotFoundException {
		try {
			Optional<Role> optional = getRoleById(id);
			if(optional.isEmpty()) {
				throw new IdNotFoundException("record not found");
			}
			else {
				repository.deleteById(id);
				return "success";
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new IdNotFoundException(e.getMessage());
		}
    }
}