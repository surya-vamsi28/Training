package com.zee.zee5app.dto;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Data
@NoArgsConstructor
@AllArgsConstructor
//@Setter(value = AccessLevel.NONE)
@ToString
@Entity
@Table(name = "subscription")
public class Subscription {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String subId;
	@NotNull
	private String dateOfPayment;
	@NotNull
	private String expiry;
	@NotNull
	private int amount;
	@NotBlank
	private String paymentMode;
	@NotBlank
	private String status;
	@NotBlank
	private String type;
	@NotBlank
	private String autorenewal;
	
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "regId")  // create foreign key
    @JsonIgnore
	private User register;

	// constructor with register
	public Subscription(String dateOfPayment, String expiry, int amount, String paymentMode, String status,
			String type, String autorenewal, User register) {
		super();
		this.dateOfPayment = dateOfPayment;
		this.expiry = expiry;
		this.amount = amount;
		this.paymentMode = paymentMode;
		this.status = status;
		this.type = type;
		this.autorenewal = autorenewal;
		this.register = register;
	}

	// constructor without register
	public Subscription(String dateOfPayment, String expiry, int amount, String paymentMode, String status,
			String type, String autorenewal) {
		super();
		this.dateOfPayment = dateOfPayment;
		this.expiry = expiry;
		this.amount = amount;
		this.paymentMode = paymentMode;
		this.status = status;
		this.type = type;
		this.autorenewal = autorenewal;
	}
}
