package com.zee.zee5app.repository.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.zee.zee5app.dto.Episode;
import com.zee.zee5app.repository.EpisodeRepository;

@Repository
public class EpisodeRepositoryImpl implements EpisodeRepository {
    @Autowired
    DataSource dataSource;
    
    @Override
    public String addEpisode(Episode episode) {
        String insertStatement = "INSERT INTO episodes "
                + "(epiId, seriesId, episodename, epilength, location, trailer) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        Connection connection = null;
        try {
        	connection = dataSource.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(insertStatement);
            preparedStatement.setString(1, episode.getEpiId());
            preparedStatement.setString(2, episode.getSeriesId());
            preparedStatement.setString(3, episode.getEpisodeName());
            preparedStatement.setInt(4, episode.getEpiLength());
            preparedStatement.setString(5, episode.getLocation());
            preparedStatement.setBytes(6, episode.getTrailer());
            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                connection.commit();
                return "Successfully added credentials";
            } else {
                connection.rollback();
                return "Error. Failed to add credentials";
            }
        } catch (SQLException e) {
            try {
                connection.rollback();
                if (e.getMessage().startsWith("Duplicate entry"))
                    return "Error: same ID already exists";
                return "Error: " + e.getMessage();
            } catch (SQLException e1) {
                e1.printStackTrace();
                return "Error: " + e.getMessage();
            }
        }
    }

	@Override
	public String deleteEpisode(Episode episode) {
        String deleteStatement = "DELETE FROM episodes WHERE epiId = ?";
        Connection connection = null;
        try {
        	connection = dataSource.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(deleteStatement);
            preparedStatement.setString(1, episode.getEpiId());
            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                connection.commit();
                return "Successfully deleted credentials";
            } else {
                connection.rollback();
                return "Error. Failed to delete credentials";
            }
        } catch (SQLException e) {
            try {
                connection.rollback();
                if (e.getMessage().startsWith("Duplicate entry"))
                    return "Error: same ID already exists";
                return "Error: " + e.getMessage();
            } catch (SQLException e1) {
                e1.printStackTrace();
                return "Error: " + e.getMessage();
            }
        }
    }

	@Override
	public String updateEpisode(Episode episode) {
        String updateStatement = "UPDATE episodes SET seriesId = ?, episodename = ?, epilength = ?, location = ?, trailer = ? WHERE epiId = ?";
        Connection connection = null;
        try {
        	connection = dataSource.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(updateStatement);
            preparedStatement.setString(1, episode.getSeriesId());
            preparedStatement.setString(2, episode.getEpisodeName());
            preparedStatement.setInt(3, episode.getEpiLength());
            preparedStatement.setString(4, episode.getLocation());
            preparedStatement.setBytes(5, episode.getTrailer());
            preparedStatement.setString(6, episode.getEpiId());
            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                connection.commit();
                return "Successfully updated credentials";
            } else {
                connection.rollback();
                return "Error. Failed to update credentials";
            }
        } catch (SQLException e) {
            try {
                connection.rollback();
                if (e.getMessage().startsWith("Duplicate entry"))
                    return "Error: same ID already exists";
                return "Error: " + e.getMessage();
            } catch (SQLException e1) {
                e1.printStackTrace();
                return "Error: " + e.getMessage();
            }
        }
    }
}