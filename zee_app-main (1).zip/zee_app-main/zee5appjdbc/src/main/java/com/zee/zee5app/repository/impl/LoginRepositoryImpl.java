package com.zee.zee5app.repository.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.zee.zee5app.dto.Login;
import com.zee.zee5app.dto.ROLE;
import com.zee.zee5app.repository.LoginRepository;
import com.zee.zee5app.utils.PasswordUtils;

@Repository
public class LoginRepositoryImpl implements LoginRepository {
	@Autowired
	DataSource dataSource;
	
	@Override
	public String addCredentials(Login login) {
        String insertStatement = "INSERT INTO login "
                + "(username, password, regId, role) "
                + "VALUES (?, ?, ?, ?)";
        Connection connection = null;
        try {
        	connection = dataSource.getConnection();
            String passwordHash = PasswordUtils.generateHash(login.getPassword());
			PreparedStatement preparedStatement = connection.prepareStatement(insertStatement);
            preparedStatement.setString(1, login.getUsername());
            preparedStatement.setString(2, passwordHash);
            preparedStatement.setString(3, login.getRegId());
            preparedStatement.setString(4, login.getRole().toString());
            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                connection.commit();
                return "Successfully added credentials";
            } else {
                connection.rollback();
                return "Error. Failed to add credentials";
            }
        } catch (SQLException e) {
            try {
                connection.rollback();
				if (e.getMessage().startsWith("Duplicate entry"))
					return "Error: same email already exists";
				return "Error: " + e.getMessage();
            } catch (SQLException e1) {
                e1.printStackTrace();
                return "Error: " + e.getMessage();
            }
        }
    }

	@Override
	public String deleteCredentials(Login login) {
        String deleteStatement = "DELETE FROM login WHERE username = ?";
        Connection connection = null;
        try {
        	connection = dataSource.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(deleteStatement);
            preparedStatement.setString(1, login.getUsername());
            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                connection.commit();
                return "Successfully deleted credentials";
            } else {
                connection.rollback();
                return "Failed to add credentials";
            }
        } catch (SQLException e) {
            try {
                connection.rollback();
            	return "Error: " + e.getMessage();	
            } catch (SQLException e1) {
                e1.printStackTrace();
            	return "Error: " + e.getMessage();	
            }
        }
    }

    @Override
    public String changePassword(String username, String password) {
        String updateStatement = "UPDATE login SET password = ? WHERE username = ?";
        Connection connection = null;
        try {
        	connection = dataSource.getConnection();
            String passwordHash = PasswordUtils.generateHash(password);
            PreparedStatement preparedStatement = connection.prepareStatement(updateStatement);
            preparedStatement.setString(1, passwordHash);
            preparedStatement.setString(2, username);
            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                connection.commit();
                return "Successfully updated credentials";
            } else {
                connection.rollback();
                return "Failed to add credentials";
            }
        } catch (SQLException e) {
            try {
                connection.rollback();
                return "Error: " + e.getMessage();
            } catch (SQLException e1) {
                e1.printStackTrace();
                return "Error: " + e.getMessage();
            }
        }
    }

    @Override
    public String changeRole(String username, ROLE role) {
        String updateStatement = "UPDATE login SET role = ? WHERE username = ?";
        Connection connection = null;
        try {
        	connection = dataSource.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(updateStatement);
            preparedStatement.setString(1, role.toString());
            preparedStatement.setString(2, username);
            int result = preparedStatement.executeUpdate();
            if (result > 0) {
                connection.commit();
                return "Successfully updated credentials";
            } else {
                connection.rollback();
                return "Failed to add credentials";
            }
        } catch (SQLException e) {
            try {
                connection.rollback();
                return "Error: " + e.getMessage();
            } catch (SQLException e1) {
                e1.printStackTrace();
                return "Error: " + e.getMessage();
            }
        }
    }
}