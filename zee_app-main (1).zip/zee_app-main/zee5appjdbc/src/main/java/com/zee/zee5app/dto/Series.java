package com.zee.zee5app.dto;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidNameException;

import lombok.*;

@Data
@ToString
public class Series {
	private String id;
	private String name;
	private int ageLimit;
	private String cast;
	private String genre;
	private int length;
	private byte[] trailer;
	private String releaseDate;
	private String language;
	private int noOfEpisodes;

	public Series() {
		super();
	}
	public Series(String id, String name, int ageLimit, String cast, String genre,
			int length, byte[] trailer, String releaseDate, String language, int noOfEpisodes) {
		super();
		try {
			this.setId(id);
			this.setName(name);
			this.setAgeLimit(ageLimit);
			this.setCast(cast);
			this.setGenre(genre);
			this.setLength(length);
			this.setTrailer(trailer);
			this.setReleaseDate(releaseDate);
			this.setLanguage(language);
			this.setNoOfEpisodes(noOfEpisodes);
		} catch (InvalidIdLengthException e) {
			System.out.println("Invalid ID length");
		} catch (InvalidNameException e) {
			System.out.println("Invalid Name length");
		}
	}
	
	public void setId(String id) throws InvalidIdLengthException {
		if (id.length() < 3)
			throw new InvalidIdLengthException("Id length is less than 3");
		this.id = id;
	}

	public void setName(String name) throws InvalidNameException {
		if (name == null || name.length() < 2)
			throw new InvalidNameException("Name length is less than 2");
		this.name = name;
	}
}
