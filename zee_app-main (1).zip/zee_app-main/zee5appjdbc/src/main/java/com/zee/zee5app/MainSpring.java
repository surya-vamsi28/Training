package com.zee.zee5app;

import javax.sql.DataSource;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.zee.zee5app.config.Config;
import com.zee.zee5app.dto.Register;
import com.zee.zee5app.repository.UserRepository;
import com.zee.zee5app.repository.impl.UserRepositoryImpl;

public class MainSpring {
	public static void main(String[] args) {
		AbstractApplicationContext applicationContext =
				new AnnotationConfigApplicationContext(Config.class);
		
		DataSource dataSource = applicationContext.getBean("ds", DataSource.class);
		System.out.println(dataSource);
		
		UserRepository userRepository = applicationContext.getBean(UserRepositoryImpl.class);
//		System.out.println(userRepository);
//		userRepository userRepository2 = applicationContext.getBean(userRepository.class);
//		System.out.println(userRepository2);
//		System.out.println(userRepository.hashCode());
//		System.out.println(userRepository2.hashCode());
//		System.out.println(userRepository.equals(userRepository2));
		System.out.println(dataSource != null);
		
		try {
			Register register = new Register("ab00003", "Praneeth", "Vadlapati",
											"praneeth1@email.com",
											"1234567890", "test12345");
			dataSource.getConnection().setAutoCommit(false);
			String result = userRepository.addUser(register);
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		applicationContext.close();
	}
}
