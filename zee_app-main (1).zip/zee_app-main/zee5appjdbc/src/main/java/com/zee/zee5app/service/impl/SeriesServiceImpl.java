package com.zee.zee5app.service.impl;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zee.zee5app.dto.Series;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.repository.*;
import com.zee.zee5app.service.SeriesService;

@Service
public class SeriesServiceImpl implements SeriesService {
	@Autowired
	private SeriesRepository repository;

	@Override
	public String addSeries(Series register)	{
		return this.repository.addSeries(register);
	}
	@Override
	public Set<Series> getSeries()	{
		return this.repository.getSeries();
	}
	@Override
	public Series getSeriesById(String id) throws IdNotFoundException, InvalidIdLengthException	{
		return this.repository.getSeriesById(id);
	}
	@Override
	public String modifySeries(String id, Series series)	{
		return this.repository.modifySeries(id, series);
	}
	@Override
	public String deleteSeries(String id)	{
		return this.repository.deleteSeries(id);
	}
}
