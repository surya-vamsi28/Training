package com.zee.zee5app.dto;

import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidNameException;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Episode {
    private String epiId;
    private String seriesId;
    private String episodeName;
    private int epiLength;
    private String location;
    private byte[] trailer;
    
    public void setEpiId(String epiId) throws InvalidIdLengthException {
        if (epiId == null || epiId.length() < 6)
            throw new InvalidIdLengthException("Invalid id length");
        this.epiId = epiId;
    }
    public void setSeriesId(String seriesId) throws InvalidIdLengthException {
        if (seriesId == null || seriesId.length() < 6)
            throw new InvalidIdLengthException("Invalid id length");
        this.seriesId = seriesId;
    }
    public void setEpisodeName(String episodeName) throws InvalidNameException {
        if (episodeName == null || episodeName.length() < 1)
            throw new InvalidNameException("Invalid name");
        this.episodeName = episodeName;
    }
}