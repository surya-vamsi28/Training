package com.zee.zee5app.repository.impl;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.zee.zee5app.dto.Subscription;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.repository.SubscriptionRepository;

@Repository
public class SubscriptionRepositoryImpl implements SubscriptionRepository {
	@Autowired
	private DataSource dataSource;
	/*
		CREATE TABLE `subscription` (
		`id` varchar(10) NOT NULL,
		`dateofpayment` date NOT NULL,
		`expiry` date NOT NULL,
		`amount` int NOT NULL,
		`paymentmode` varchar(15) NOT NULL,
		`status` varchar(20) NOT NULL,
		`type` varchar(10) NOT NULL,
		`autorenewal` varchar(10) NOT NULL,
		PRIMARY KEY (`id`),
		CONSTRAINT `regId_sub_FK` FOREIGN KEY (`id`) REFERENCES `register` (`regId`),
		CONSTRAINT `autorenewal_check_ck` CHECK ((`autorenewal` in (_utf8mb4'True',_utf8mb4'False'))),
		CONSTRAINT `paymentmode_check_ck` CHECK ((`paymentmode` in (_utf8mb4'CREDITCARD',_utf8mb4'NETBANKING',_utf8mb4'DEBITCARD')))
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
	*/

    @Override
	public String addSubscription(Subscription subscription)	{
		String insertStatement = "INSERT INTO subscription "
				+ "(id, dateofpayment, expiry, amount, paymentmode, status, type, autorenewal) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(insertStatement);
			preparedStatement.setString(1, subscription.getId());
			preparedStatement.setDate(2, Date.valueOf(subscription.getDateOfPayment()));
			preparedStatement.setDate(3, Date.valueOf(subscription.getExpiry()));
			preparedStatement.setInt(4, subscription.getAmount());
			preparedStatement.setString(5, subscription.getPaymentMode());
			preparedStatement.setString(6, subscription.getStatus());
			preparedStatement.setString(7, subscription.getType());
			preparedStatement.setString(8, subscription.getAutorenewal());
			int result = preparedStatement.executeUpdate();
			if (result > 0)	{
				connection.commit();
				return "addSubscription: Successfully added subscription";
			}
			else	{
				connection.rollback();
				return "addSubscription: Failed to add subscription";
			}
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			return "addSubscription: Failed to add subscription";
		}
	}
    @Override
	public Set<Subscription> getSubscriptions()	{
		String selectStatement = "SELECT * FROM subscription";
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(selectStatement);
			ResultSet resultSet = preparedStatement.executeQuery();
			Set<Subscription> subscriptions = new HashSet<>();
			while (resultSet.next()) {
				try {
					Subscription subscription = new Subscription();
					subscription.setId(resultSet.getString("id"));
					subscription.setDateOfPayment(resultSet.getDate("dateofpayment").toString());
					subscription.setExpiry(resultSet.getDate("expiry").toString());
					subscription.setAmount(resultSet.getInt("amount"));
					subscription.setPaymentMode(resultSet.getString("paymentmode"));
					subscription.setStatus(resultSet.getString("status"));
					subscription.setType(resultSet.getString("type"));
					subscription.setAutorenewal(resultSet.getString("autorenewal"));
					subscriptions.add(subscription);
				} catch (Exception e) {
					System.out.println("getSubscriptions: Failed to add subscription");
				}
			}
			return subscriptions;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
    @Override
	public Subscription getSubscriptionById(String id) throws IdNotFoundException, InvalidIdLengthException	{
		if (id.length() < 6)
			throw new InvalidIdLengthException("Invalid Id Length");
		String selectStatement = "SELECT * FROM subscription WHERE id = ?";
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(selectStatement);
			preparedStatement.setString(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				try {
					Subscription subscription = new Subscription();
					subscription.setId(resultSet.getString("id"));
					subscription.setDateOfPayment(resultSet.getDate("dateofpayment").toString());
					subscription.setExpiry(resultSet.getDate("expiry").toString());
					subscription.setAmount(resultSet.getInt("amount"));
					subscription.setPaymentMode(resultSet.getString("paymentmode"));
					subscription.setStatus(resultSet.getString("status"));
					subscription.setType(resultSet.getString("type"));
					subscription.setAutorenewal(resultSet.getString("autorenewal"));
					return subscription;
				} catch (Exception e) {
					System.out.println("getSubscriptionById: Failed to add subscription");
					return null;
				}
			} else
				throw new IdNotFoundException("Id Not Found");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new IdNotFoundException("Id Not Found");
		}
	}

    @Override
	public String modifySubscription(String id, Subscription subscription)	{
		String updateStatement = "UPDATE subscription SET "
				+ "dateofpayment = ?, expiry = ?, amount = ?, paymentmode = ?, status = ?, type = ?, autorenewal = ? "
				+ "WHERE id = ?";
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(updateStatement);
			preparedStatement.setDate(1, Date.valueOf(subscription.getDateOfPayment()));
			preparedStatement.setDate(2, Date.valueOf(subscription.getExpiry()));
			preparedStatement.setInt(3, subscription.getAmount());
			preparedStatement.setString(4, subscription.getPaymentMode());
			preparedStatement.setString(5, subscription.getStatus());
			preparedStatement.setString(6, subscription.getType());
			preparedStatement.setString(7, subscription.getAutorenewal());
			preparedStatement.setString(8, id);
			int result = preparedStatement.executeUpdate();
			if (result > 0)	{
				connection.commit();
				return "modifySubscription: subscription modified successfully";
			} else {
				connection.rollback();
				return "modifySubscription: subscription modification failed";
			}
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			return "modifySubscription: subscription modification failed";
		}
	}
	
    @Override
	public String deleteSubscription(String id)	{
		String deleteStatement = "DELETE FROM subscription WHERE id = ?";
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(deleteStatement);
			preparedStatement.setString(1, id);
			int result = preparedStatement.executeUpdate();
			if (result > 0)	{
				connection.commit();
				return "deleteSubscription: subscription deleted successfully";
			} else {
				connection.rollback();
				return "deleteSubscription: subscription deletion failed";
			}
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			return "deleteSubscription: subscription deletion failed";
		}
	}
}