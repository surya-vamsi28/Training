//package com.zee.zee5app;
//import java.io.IOException;
//import java.math.BigDecimal;
//import java.util.Optional;
//
//import com.zee.zee5app.dto.Register;
//import com.zee.zee5app.exception.IdNotFoundException;
//import com.zee.zee5app.exception.InvalidEmailException;
//import com.zee.zee5app.exception.InvalidIdLengthException;
//import com.zee.zee5app.exception.InvalidNameException;
//import com.zee.zee5app.exception.InvalidPasswordException;
//import com.zee.zee5app.repository.UserRepository;
//import com.zee.zee5app.service.UserService;
//import com.zee.zee5app.service.impl.UserServiceImpl;
//
//public class Main_old {
//	public static void main(String[] args) {
//		Register register = null;
//		try {
//			register = new Register();
//			register.setId("ab0001");
//			register.setFirstName("Praneeth");
//			register.setLastName("Vadlapati");
//			register.setEmail("praneeth@email.com");
//			register.setContactNumber(new BigDecimal("1234567890"));
//			register.setPassword("test1234");
//		} catch (InvalidNameException e) {
//			System.out.println("InvalidNameException: " + e);
//		} catch (InvalidIdLengthException e) {
//			System.out.println("InvalidIdLengthException: " + e);
//		} catch (InvalidEmailException e) {
//			System.out.println("InvalidEmailException: " + e);
//		} catch (InvalidPasswordException e) {
//			System.out.println("InvalidPasswordException: " + e);
//		} catch (Exception e) {
//			System.out.println("Exception: " + e);
//		}
//		
//		UserService service;
//		try {
//			service = UserServiceImpl.getInstance();
//		} catch (IOException e) {
//			return;  // return back from the main method
//		}
//		service.addUser(register);
//		
//		try {
//			Optional<Register> result = service.getUserById("ab0001");
//			System.out.println("getUserById: " + result.get());
//		} catch (IdNotFoundException e) {
//			System.out.println("ID not found");
//		}
//		
//		printUsers(service);
//		
//		try {
//			register.setPassword("test1234");
//			register.setLastName("V");
//		} catch (InvalidPasswordException e) {
//			e.printStackTrace();
//		} catch (InvalidNameException e) {
//			e.printStackTrace();
//		}
//		String result = null;
//		try {
//			result = service.updateUser("ab0001", register);
//			System.out.println("Update user: " + result);
//		} catch (IdNotFoundException e1) {
//			System.out.println("ID not found. Can't update");
//		}  // change password
//		// printUsers(service);
//
//		try {
//			String result2 = service.deleteUserById("ab0001");
//			System.out.println("Delete user: " + result2);
//		} catch (Exception e) {  // IdNotFoundException
//			System.out.println("ID not found");
//		}
//		// printUsers(service);
//		
//		try {
//			UserService service2 = UserServiceImpl.getInstance();
//			Optional<Register> register2 = service.getUserById("ab0001");
//		} catch (IOException|IdNotFoundException e) {
//			System.out.println("Exception: " + e);
//		}
//		
//		// System.out.println("Running completed. All the exceptions are handled.");
//	}
//	static void printUsers(UserService service)	{
//		System.out.println("printUsers: ");
//		// return if user details are not available
//		try {
//		if (service.getAllUserDetails() == null)	{
//			System.out.println("No users available");
//			return;
//		}
//		service.getAllUserDetails().forEach(register -> System.out.println(register.get()));
//		/* for (Register register: service.getAllUserDetails())
//			if (register != null)
//				System.out.println(register); */
//		} catch(Exception e) {
//			System.out.println("Exception: " + e.toString());
//		}
//	}
//}
