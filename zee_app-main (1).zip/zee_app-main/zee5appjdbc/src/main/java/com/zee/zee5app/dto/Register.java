package com.zee.zee5app.dto;

import java.math.BigDecimal;

import com.zee.zee5app.exception.InvalidEmailException;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidNameException;
import com.zee.zee5app.exception.InvalidPasswordException;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;
import lombok.ToString;


@Data
@Setter(value = AccessLevel.NONE)
@ToString
public class Register implements Comparable<Register> {
	private String id;  // at least 6 chars long
	private String firstName;
	private String lastName;
	private String email;
	private String password;
	private BigDecimal contactNumber;
	// private will be accessible only inside the class

	public Register() {
		super();
	}
	public Register(String id, String firstName, String lastName,
			String email, String contactNumber, String password)
			throws InvalidIdLengthException, InvalidNameException,
			InvalidEmailException, InvalidPasswordException {
		super();
		try {
			this.setId(id);
			this.setFirstName(firstName);
			this.setLastName(lastName);
			this.setEmail(email);
			this.setContactNumber(contactNumber);
			this.setPassword(password);
		} catch (InvalidIdLengthException e) {
			e.printStackTrace();
		} catch (InvalidNameException e) {
			e.printStackTrace();
		} catch (InvalidEmailException e) {
			e.printStackTrace();
		} catch (InvalidPasswordException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void setId(String id) throws InvalidIdLengthException {
		if (id.length() < 6)
			throw new InvalidIdLengthException("Id length is less than 6");
		this.id = id;
	}
	public void setFirstName(String firstName) throws InvalidNameException {
		if (firstName == null || firstName.length() < 2)
			throw new InvalidNameException("Name length is less than 2");
		this.firstName = firstName;
	}
	public void setLastName(String lastName) throws InvalidNameException {
		if (firstName == null || firstName.length() < 2)
			throw new InvalidNameException("Name length is less than 2");
		this.lastName = lastName;
	}
	public void setEmail(String email) throws InvalidEmailException {
		if (email == null || email.length() < 8 || !email.contains("@")
				|| email.endsWith(".com")==false)
			throw new InvalidEmailException("Invalid email entered");
		this.email = email;
	}
	public void setPassword(String password) throws InvalidPasswordException {
		if (password == null || password.length() < 8
				|| password.matches("[A-Za-z0-9]+") == false)
			throw new InvalidPasswordException("Invalid password entered");
		this.password = password;
	}
	public void setContactNumber(BigDecimal contactNumber) {
		this.contactNumber = contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = new BigDecimal(contactNumber);
	}
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		Register other = (Register) obj;
//		return Objects.equals(email, other.email) && Objects.equals(firstName, other.firstName)
//				&& Objects.equals(id, other.id) && Objects.equals(lastName, other.lastName)
//				&& Objects.equals(password, other.password) && Objects.equals(contactNumber, other.contactNumber);
//	}
//	@Override
//	public int hashCode() {
//		return Objects.hash(email, firstName, id, lastName, password);
//	}
	@Override
	public int compareTo(Register other)	{
		// return 0;
		return this.id.compareTo(other.getId());
	}
}
