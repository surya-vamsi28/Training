package com.zee.zee5app.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zee.zee5app.dto.Register;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.exception.InvalidEmailException;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidNameException;
import com.zee.zee5app.exception.InvalidPasswordException;
import com.zee.zee5app.repository.UserRepository;
import com.zee.zee5app.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepository repository;

	@Override
	public String addUser(Register register) {
		return repository.addUser(register);
	}

	@Override
	public Optional<Register> getUserById(String id) throws IdNotFoundException {
		return repository.getUserById(id);
	}

	@Override
	public Register[] getAllUsers()  throws IdNotFoundException,
		InvalidIdLengthException, InvalidNameException, InvalidEmailException,
		InvalidPasswordException{
		return repository.getAllUsers();
	}

	@Override
	public Optional<List<Register>> getAllUserDetails() throws IdNotFoundException, InvalidIdLengthException, InvalidNameException, InvalidEmailException, InvalidPasswordException	{
		return repository.getAllUserDetails();
	}

	@Override
	public String updateUser(String id, Register register) throws IdNotFoundException {
		return repository.updateUser(id, register);
	}

	@Override
	public String deleteUserById(String id) throws IdNotFoundException {
		return repository.deleteUserById(id);
	}
}
