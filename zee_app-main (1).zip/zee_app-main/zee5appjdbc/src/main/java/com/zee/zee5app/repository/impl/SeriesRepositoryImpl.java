package com.zee.zee5app.repository.impl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.zee.zee5app.dto.Series;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.repository.SeriesRepository;

@Repository
public class SeriesRepositoryImpl implements SeriesRepository {
	@Autowired
	private DataSource dataSource;

	/*
		CREATE TABLE `series` (
		`id` varchar(10) NOT NULL,
		`name` varchar(45) NOT NULL,
		`agelimit` int NOT NULL,
		`cast` varchar(45) NOT NULL,
		`genre` varchar(45) NOT NULL,
		`length` int NOT NULL,
		`trailer` longblob,
		`releasedate` date NOT NULL,
		`language` varchar(45) NOT NULL,
		`noofepisodes` int NOT NULL,
		PRIMARY KEY (`id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
	*/

    @Override
	public String addSeries(Series ser) {
		String insertStatement = "INSERT INTO series "
				+ "(id, name, agelimit, cast, genre, length, trailer, releasedate, language, noofepisodes) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(insertStatement);
			preparedStatement.setString(1, ser.getId());
			preparedStatement.setString(2, ser.getName());
			preparedStatement.setInt(3, ser.getAgeLimit());
			preparedStatement.setString(4, ser.getCast());
			preparedStatement.setString(5, ser.getGenre());
			preparedStatement.setInt(6, ser.getLength());
			// preparedStatement.setBytes(7, ser.getTrailer());
			preparedStatement.setBytes(7, null);
			preparedStatement.setDate(8, Date.valueOf(ser.getReleaseDate()));
			preparedStatement.setString(9, ser.getLanguage());
			preparedStatement.setInt(10, ser.getNoOfEpisodes());
			int result = preparedStatement.executeUpdate();
			if (result == 1)	{
				connection.commit();
				return "Series added successfully";
			} else {
				connection.rollback();
				return "Series not added";
			}
		} catch (SQLException e) {
			try	{
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			return "Failed to add series";
		}
	}
    @Override
	public Set<Series> getSeries() {
		String selectStatement = "SELECT * FROM series";
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(selectStatement);
			ResultSet resultSet = preparedStatement.executeQuery();
			Set<Series> series = new HashSet<>();
			while (resultSet.next()) {
				try {
					Series ser = new Series();
					ser.setId(resultSet.getString("id"));
					ser.setName(resultSet.getString("name"));
					ser.setAgeLimit(resultSet.getInt("agelimit"));
					ser.setCast(resultSet.getString("cast"));
					ser.setGenre(resultSet.getString("genre"));
					ser.setLength(resultSet.getInt("length"));
					// ser.setTrailer(resultSet.getBytes("trailer"));
					ser.setTrailer(null);
					ser.setReleaseDate(resultSet.getDate("releasedate").toString());
					ser.setLanguage(resultSet.getString("language"));
					ser.setNoOfEpisodes(resultSet.getInt("noofepisodes"));
					series.add(ser);
				} catch (Exception e) {
					System.out.println("getSeries: Error adding movie");
				}
			}
			return series;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
    @Override
	public Series getSeriesById(String id) throws IdNotFoundException, InvalidIdLengthException {
		if (id.length() <= 6)
			throw new InvalidIdLengthException("ID is too short: " + id.length());
		String selectStatement = "SELECT * FROM series WHERE id = ?";
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(selectStatement);
			preparedStatement.setString(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				try {
					Series ser = new Series();
					ser.setId(resultSet.getString("id"));
					ser.setName(resultSet.getString("name"));
					ser.setAgeLimit(resultSet.getInt("agelimit"));
					ser.setCast(resultSet.getString("cast"));
					ser.setGenre(resultSet.getString("genre"));
					ser.setLength(resultSet.getInt("length"));
					// ser.setTrailer(resultSet.getBytes("trailer"));
					ser.setTrailer(null);
					ser.setReleaseDate(resultSet.getDate("releasedate").toString());
					ser.setLanguage(resultSet.getString("language"));
					ser.setNoOfEpisodes(resultSet.getInt("noofepisodes"));
					return ser;
				} catch (Exception e) {
					System.out.println("getSeriesById: Error adding movie");
					return null;
				}
			} else
				throw new IdNotFoundException("ID is not found");
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
    @Override
	public String modifySeries(String id, Series series) {
		String updateStatement = "UPDATE series SET "
				+ "name = ?, agelimit = ?, cast = ?, genre = ?, length = ?, trailer = ?, releasedate = ?, language = ?, noofepisodes = ? "
				+ "WHERE id = ?";
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(updateStatement);
			preparedStatement.setString(1, series.getName());
			preparedStatement.setInt(2, series.getAgeLimit());
			preparedStatement.setString(3, series.getCast());
			preparedStatement.setString(4, series.getGenre());
			preparedStatement.setInt(5, series.getLength());
			// preparedStatement.setBytes(6, series.getTrailer());
			preparedStatement.setBytes(6, null);
			preparedStatement.setDate(7, Date.valueOf(series.getReleaseDate()));
			preparedStatement.setString(8, series.getLanguage());
			preparedStatement.setInt(9, series.getNoOfEpisodes());
			preparedStatement.setString(10, id);
			int result = preparedStatement.executeUpdate();
			if (result > 0) {
				connection.commit();
				return "Series modified successfully";
			} else {
				connection.rollback();
				return "Series not modified";
			}
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			return "Failed to modify series";
		}
	}
    @Override
	public String deleteSeries(String id) {
		String deleteStatement = "DELETE FROM series WHERE id = ?";
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(deleteStatement);
			preparedStatement.setString(1, id);
			int result = preparedStatement.executeUpdate();
			if (result > 0) {
				connection.commit();
				return "Series deleted successfully";
			} else {
				connection.rollback();
				return "Series not deleted";
			}
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			return "Failed to delete series";
		}
	}
}