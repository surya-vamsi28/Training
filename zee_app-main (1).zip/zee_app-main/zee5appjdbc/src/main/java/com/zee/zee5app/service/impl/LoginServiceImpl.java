package com.zee.zee5app.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zee.zee5app.dto.Login;
import com.zee.zee5app.dto.ROLE;
import com.zee.zee5app.repository.LoginRepository;
import com.zee.zee5app.service.LoginService;

@Service
public class LoginServiceImpl implements LoginService {
	@Autowired
	private LoginRepository repository;

	@Override
	public String addCredentials(Login login) {
		return this.repository.addCredentials(login);
	}
	@Override
	public String deleteCredentials(Login login) {
		return this.repository.deleteCredentials(login);
	}
	@Override
	public String changePassword(String username, String password) {
		return this.repository.changePassword(username, password);
	}
	@Override
	public String changeRole(String username, ROLE role) {
		return this.repository.changeRole(username, role);
	}
}
