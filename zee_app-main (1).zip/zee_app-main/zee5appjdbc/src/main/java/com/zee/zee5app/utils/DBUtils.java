package com.zee.zee5app.utils;

import java.io.IOException;
import java.io.InputStream;
//import Connection and driver class
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.springframework.stereotype.Component;

@Component
public class DBUtils {
	// used to get and close DB connections
	private static DBUtils dbUtils = null;
	private static Properties properties = null;
	private static Connection connection = null;
	
	public static Connection getConnection() {
		// connection with database
		try {
			properties = loadProperties();
			if (connection == null || connection.isClosed()) {
				connection = DriverManager.getConnection(
						properties.getProperty("jdbc.url"),
						properties.getProperty("jdbc.username"),
						properties.getProperty("jdbc.password")
				);
				// System.out.println(properties);
				connection.setAutoCommit(false);
			}
			return connection;
		} catch (Exception e) {
			System.out.println("Error while loading properties file");
		}
		return null;
	}

	public static void closeConnection(Connection connection) {
		try {
			if (connection != null)
				connection.close();
		} catch (SQLException e) {
			System.out.println("Error while closing connection");
		}
	}

	private static Properties loadProperties() throws IOException {
		// read properties file
		InputStream inputStream = 
			DBUtils.class.getClassLoader()
			.getResourceAsStream("application.properties");
		
		// getResourceAsStream looks for particular file with resource folder
		// Properties is a predefined class
		Properties properties = new Properties();
		// reads the properties internally
		properties.load(inputStream);

		return properties;
	}
}
