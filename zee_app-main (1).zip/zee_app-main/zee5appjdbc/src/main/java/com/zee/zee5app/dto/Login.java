package com.zee.zee5app.dto;

import com.zee.zee5app.exception.InvalidEmailException;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Login {
	private String username;
	private String password;
	private String regId;
	private ROLE role;
	
	public void setUsername(String email) throws InvalidEmailException {
		// consider regId is email
		if (email == null || email.length() < 8 || !email.contains("@")
				|| email.endsWith(".com")==false)
			throw new InvalidEmailException("Invalid email entered");
		this.username = email;
	}
}
