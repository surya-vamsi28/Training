package com.zee.zee5app.service;

import com.zee.zee5app.dto.Episode;

public interface EpisodeService {
    public String addEpisode(Episode episode);
    public String deleteEpisode(Episode episode);
    public String updateEpisode(Episode episode);
}