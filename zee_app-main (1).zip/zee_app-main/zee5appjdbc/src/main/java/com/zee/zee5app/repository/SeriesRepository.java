package com.zee.zee5app.repository;
import java.util.Set;

import com.zee.zee5app.dto.*;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.exception.InvalidIdLengthException;

public interface SeriesRepository {
	public String addSeries(Series series);
	public Set<Series> getSeries();
	public Series getSeriesById(String id) throws IdNotFoundException, InvalidIdLengthException;
	public String modifySeries(String id, Series series);
	public String deleteSeries(String id);
}

