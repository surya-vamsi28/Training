package com.zee.zee5app;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.zee.zee5app.config.Config;
import com.zee.zee5app.dto.Episode;
import com.zee.zee5app.dto.Movie;
import com.zee.zee5app.dto.Series;
import com.zee.zee5app.dto.Subscription;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidNameException;
import com.zee.zee5app.service.*;
import com.zee.zee5app.service.impl.*;

public class Main_assignment {
	public static void main(String[] args) {
		AbstractApplicationContext applicationContext =
				new AnnotationConfigApplicationContext(Config.class);
		
		// test the subscription service
		System.out.println("SubscriptionService");
		SubscriptionService service = applicationContext.getBean(SubscriptionServiceImpl.class);
		Subscription subscription = new Subscription("ab00001", "2020-01-01", "2021-01-01",
				1, "CREDITCARD", "Active", "Monthly", "False");
		System.out.println("addSubscription: " + service.addSubscription(subscription));
		try {
			System.out.println("getSubscriptionById: " + (service.getSubscriptionById("ab00001") != null));
		} catch (IdNotFoundException e) {
			System.out.println("ID not found");
		} catch (InvalidIdLengthException e) {
			System.out.println("Invalid Id Length Exception");
		}
		for (Subscription sub : service.getSubscriptions())
			if (sub != null)
				System.out.println("getSubscriptions: " + sub);
		subscription.setAutorenewal("False");
		System.out.println("modifySubscription: " + service.modifySubscription("ab00001", subscription));
		System.out.println("deleteSubscription: " + service.deleteSubscription("ab00001"));
		
		// test the movie service
		System.out.println();
		System.out.println("movieService");
		MovieService movieService = applicationContext.getBean(MovieServiceImpl.class);
		Movie movie = new Movie("ab00001", "Avatar", 10, "Cast1, Cast2", "Action",
				2 * 60 * 60, "https://www.youtube.com/watch?v=5PSNL1qE6VY", 
				"2020-01-01", "English");
		System.out.println(movieService.addMovie(movie));
		try {
			System.out.println(movieService.getMovieById("ab00001") != null);
		} catch (IdNotFoundException e) {
			System.out.println("ID not found");
		}
		for (Movie mov: movieService.getMovies())
			if (mov != null)
				System.out.println(mov);
		try {
			movie.setName("Avatar 2");
		} catch (InvalidNameException e) {
			System.out.println("Invalid name");
		}
		System.out.println(movieService.modifyMovie("ab00001", movie));
		System.out.println(movieService.deleteMovie("ab00001"));
		
		// test the series service
		System.out.println(); 
		System.out.println("SeriesService");
		SeriesService seriesService = applicationContext.getBean(SeriesServiceImpl.class);
		Series series = new Series("ab00001", "Dark", 10, "Cast1, Cast2", "Action",
				2 * 60 * 60, null,  "2020-01-01", "English", 10);
		System.out.println("addSeries: " + seriesService.addSeries(series));
		try {
			System.out.println(seriesService.getSeriesById("ab00001") != null);
		} catch (IdNotFoundException e) {
			System.out.println("ID not found");
		} catch (InvalidIdLengthException e) {
			System.out.println("Invalid Id Length");
		}
		for (Series ser: seriesService.getSeries())
			if (ser != null)
				System.out.println(ser);
		try {
			series.setName("Dark 2");
			series.setReleaseDate("2010-01-01");
		} catch (InvalidNameException e) {
			System.out.println("Unable to set new details");
		}
		System.out.println(seriesService.modifySeries("ab00001", series));
		System.out.println(seriesService.deleteSeries("ab00001"));

		// test the episode service
//		System.out.println();
//		System.out.println("EpisodeService");
//		EpisodeService episodeService = applicationContext.getBean(EpisodeServiceImpl.class);
//		Episode episode = new Episode("ab00001");
//		System.out.println("addEpisode: " + episodeService.addEpisode(episode));
//		try {
//			System.out.println(episodeService.getEpisodeById("ab00001") != null);
//		} catch (IdNotFoundException e) {
//			System.out.println("ID not found");
//		} catch (InvalidIdLengthException e) {
//			System.out.println("Invalid Id Length");
//		}
//
//		for (Episode ep: episodeService.getEpisodes())
//			if (ep != null)
//				System.out.println(ep);
//
//		try {
//			episode.setName("Dark 2");
//			episode.setReleaseDate("2010-01-01");
//		} catch (InvalidNameException e) {
//			System.out.println("Unable to set new details");
//		}
//		System.out.println(episodeService.modifyEpisode("ab00001", episode));
//		System.out.println(episodeService.deleteEpisode("ab00001"));
	}
}
