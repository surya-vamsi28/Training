package com.zee.zee5app.dto;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidNameException;

import lombok.*;


@Data
@ToString
public class Movie {
	private String id;
	private String name;
	private int ageLimit;
	private String cast;
	private String genre;
	private int length;
	private String trailer;
	private String releaseDate;
	private String language;

	public Movie() {
		super();
	}
	public Movie(String id, String name, int ageLimit, String cast, String genre,
			int length, String trailer, String releaseDate, String language) {
		super();
		try {
			this.setId(id);
			this.setName(name);
			this.setAgeLimit(ageLimit);
			this.setCast(cast);
			this.setGenre(genre);
			this.setLength(length);
			this.setTrailer(trailer);
			this.setReleaseDate(releaseDate);
			this.setLanguage(language);
		} catch (InvalidIdLengthException e) {
			System.out.println("Invalid ID length");
		} catch (InvalidNameException e) {
			System.out.println("Invalid Name");
		}
	}
	
	public void setId(String id) throws InvalidIdLengthException {
		if (id.length() < 3)
			throw new InvalidIdLengthException("Id length is less than 3");
		this.id = id;
	}

	public void setName(String name) throws InvalidNameException {
		if (name == null || name.length() < 2)
			throw new InvalidNameException("Name length is less than 2");
		this.name = name;
	}
}
