package com.zee.zee5app.repository.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.zee.zee5app.dto.Movie;
import com.zee.zee5app.exception.IdNotFoundException;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidNameException;
import com.zee.zee5app.repository.MovieRepository;

@Repository
public class MovieRepositoryImpl implements MovieRepository {
	@Autowired
	private DataSource dataSource;

	/* 
		CREATE TABLE `movies` (
		`id` varchar(10) NOT NULL,
		`name` varchar(45) NOT NULL,
		`agelimit` int NOT NULL,
		`cast` varchar(45) NOT NULL,
		`genre` varchar(45) NOT NULL,
		`length` int NOT NULL,
		`trailer` varchar(45) DEFAULT NULL,
		`releasedate` date NOT NULL,
		`language` varchar(45) NOT NULL,
		PRIMARY KEY (`id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
	*/

	@Override
	public String addMovie(Movie movie) {
		String insertStatement = "INSERT INTO movies "
				+ "(id, name, agelimit, cast, genre, length, trailer, releasedate, language) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(insertStatement);
			preparedStatement.setString(1, movie.getId());
			preparedStatement.setString(2, movie.getName());
			preparedStatement.setInt(3, movie.getAgeLimit());
			preparedStatement.setString(4, movie.getCast());
			preparedStatement.setString(5, movie.getGenre());
			preparedStatement.setInt(6, movie.getLength());
			preparedStatement.setString(7, movie.getTrailer());
			preparedStatement.setDate(8, Date.valueOf(movie.getReleaseDate()));
			preparedStatement.setString(9, movie.getLanguage());
			int result = preparedStatement.executeUpdate();
			if (result > 0) {
				connection.commit();
				return "addMovie: Successfully added movie";
			} else {
				connection.rollback();
				return "addMovie: Error. Failed to add movie";
			}
		} catch (SQLException e) {
			try {
				connection.rollback();
				return "addMovie: Error: " + e.getMessage();
			} catch (SQLException e1) {
				e1.printStackTrace();
				return "addMovie: Error: " + e.getMessage();
			}
		}
	}

	@Override
	public Set<Movie> getMovies() {
		String selectStatement = "SELECT * FROM movies";
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(selectStatement);
			Set<Movie> movies = new HashSet<>();
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				try {
					Movie movie = new Movie();
					movie.setId(resultSet.getString("id"));
					movie.setName(resultSet.getString("name"));
					movie.setAgeLimit(resultSet.getInt("agelimit"));
					movie.setCast(resultSet.getString("cast"));
					movie.setGenre(resultSet.getString("genre"));
					movie.setLength(resultSet.getInt("length"));
					movie.setTrailer(resultSet.getString("trailer"));
					movie.setReleaseDate(resultSet.getDate("releasedate").toString());
					movie.setLanguage(resultSet.getString("language"));
					movies.add(movie);
				} catch (Exception e) {
					System.out.println("getMovies: Error adding movie");
				}
			}
			if (movies.size() == 0)
				System.out.println("getMovies: No movies found");
			return movies;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public Movie getMovieById(String id) throws IdNotFoundException {
		String selectStatement = "SELECT * FROM movies WHERE id = ?";
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(selectStatement);
			preparedStatement.setString(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				Movie movie = new Movie();
				try {
					movie.setId(resultSet.getString("id"));
					movie.setName(resultSet.getString("name"));
					movie.setAgeLimit(resultSet.getInt("agelimit"));
					movie.setCast(resultSet.getString("cast"));
					movie.setGenre(resultSet.getString("genre"));
					movie.setLength(resultSet.getInt("length"));
					movie.setTrailer(resultSet.getString("trailer"));
					movie.setReleaseDate(resultSet.getDate("releasedate").toString());
					movie.setLanguage(resultSet.getString("language"));
					return movie;
				} catch (InvalidIdLengthException e) {
					System.out.println("getMovieById: Error: " + e.getMessage());
					return null;
				} catch (InvalidNameException e) {
					System.out.println("getMovieById: Error: " + e.getMessage());
					return null;
				}
			} else {
				throw new IdNotFoundException("getMovieById: Error. Movie with id " + id + " not found");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public String modifyMovie(String id, Movie movie) {
		String updateStatement = "UPDATE movies SET name = ?, agelimit = ?, cast = ?, genre = ?, length = ?, "
			+ "trailer = ?, releasedate = ?, language = ? WHERE id = ?";
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(updateStatement);
			preparedStatement.setString(1, movie.getName());
			preparedStatement.setInt(2, movie.getAgeLimit());
			preparedStatement.setString(3, movie.getCast());
			preparedStatement.setString(4, movie.getGenre());
			preparedStatement.setInt(5, movie.getLength());
			preparedStatement.setString(6, movie.getTrailer());
			preparedStatement.setDate(7, Date.valueOf(movie.getReleaseDate()));
			preparedStatement.setString(8, movie.getLanguage());
			preparedStatement.setString(9, id);
			int result = preparedStatement.executeUpdate();
			if (result > 0) {
				connection.commit();
				return "modifyMovie: Successfully modified movie";
			} else {
				connection.rollback();
				return "modifyMovie: Error. Failed to modify movie";
			}
		} catch (SQLException e) {
			try {
				connection.rollback();
				return "modifyMovie: Error: " + e.getMessage();
			} catch (SQLException e1) {
				e1.printStackTrace();
				return "modifyMovie: Error: " + e.getMessage();
			}
		}
	}

	@Override
	public String deleteMovie(String id) {
		String deleteStatement = "DELETE FROM movies WHERE id = ?";
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(deleteStatement);
			preparedStatement.setString(1, id);
			int result = preparedStatement.executeUpdate();
			if (result > 0) {
				connection.commit();
				return "deleteMovie: Successfully deleted movie";
			} else {
				connection.rollback();
				return "deleteMovie: Error. Failed to delete movie";
			}
		} catch (SQLException e) {
			try {
				connection.rollback();
				return "deleteMovie: Error: " + e.getMessage();
			} catch (SQLException e1) {
				e1.printStackTrace();
				return "deleteMovie: Error: " + e.getMessage();
			}
		}
	}
}
