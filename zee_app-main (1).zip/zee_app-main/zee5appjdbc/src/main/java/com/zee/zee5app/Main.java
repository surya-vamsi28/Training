package com.zee.zee5app;

import com.zee.zee5app.service.LoginService;
import com.zee.zee5app.service.UserService;
import com.zee.zee5app.service.impl.LoginServiceImpl;
import com.zee.zee5app.service.impl.UserServiceImpl;
import com.zee.zee5app.utils.PasswordUtils;

import java.io.IOException;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.zee.zee5app.config.Config;
import com.zee.zee5app.dto.Login;
import com.zee.zee5app.dto.ROLE;
import com.zee.zee5app.dto.Register;

public class Main {

	public static void main(String[] args) throws IOException {
		AbstractApplicationContext applicationContext =
				new AnnotationConfigApplicationContext(Config.class);
		LoginService loginService = applicationContext.getBean(LoginServiceImpl.class);
		try {
			String myPassword = "myPassword123";
			String securedPassword = PasswordUtils.generateHash(myPassword);
			System.out.println("My secure password = " + securedPassword);			
			
			UserService userService = applicationContext.getBean(UserServiceImpl.class);

			Register register = new Register("ab00006", "Praneeth", "Vadlapati",
					"praneeth@email.com", "1234567890", "test12345");
			String res = userService.addUser(register);
			System.out.println("addUser: " + res);

			// add same user to Login table
			Login login = new Login(register.getEmail(), register.getPassword(),
					register.getId(), ROLE.ROLE_USER);
			if (!res.startsWith("Error")) {  // userService game no error
				res = loginService.addCredentials(login);
				System.out.println("addCredentials: " + res);
			}
			
			printUsers(userService);

			// change password
			login.setPassword("test123456");  // new password
			res = loginService.changePassword(login.getUsername(), login.getPassword());
			System.out.println("changePassword: " + res);

			// change role
			login.setRole(ROLE.ROLE_ADMIN);
			res = loginService.changeRole(login.getUsername(), login.getRole());
			System.out.println("loginService: " + res);

//			res = userService.deleteUserById("ab00001");
//			System.out.println("deleteUserById: " + res);
			// will be automatically deleted from Login table
			
			// printUsers(userService);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	static void printUsers(UserService userService) {  // print all users
		System.out.println("Print all users: ");
		try {
			Register[] result = userService.getAllUsers();
			if (result == null)
				System.out.println("printUsers: No users found");
			else
				for (Register register : result)
					System.out.println(register);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
