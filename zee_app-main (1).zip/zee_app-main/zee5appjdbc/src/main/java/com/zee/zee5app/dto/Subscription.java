package com.zee.zee5app.dto;
import com.zee.zee5app.exception.InvalidIdLengthException;
import com.zee.zee5app.exception.InvalidNameException;

import lombok.*;

@Data
@ToString
public class Subscription {
	private String id;
	private String dateOfPayment;
	private String expiry;
	private int amount;
	private String paymentMode;
	private String status;
	private String type;
	private String autorenewal;

	public Subscription() {
		super();
	}
	public Subscription(String id, String dateOfPayment, String expiry, int amount, 
			String paymentMode, String status, String type, String autorenewal) {
		super();
		try {
			this.setId(id);
			this.setDateOfPayment(dateOfPayment);
			this.setExpiry(expiry);
			this.setAmount(amount);
			this.setPaymentMode(paymentMode);
			this.setStatus(status);
			this.setType(type);
			this.setAutorenewal(autorenewal);
		} catch (InvalidIdLengthException e) {
			System.out.println("Invalid ID length");
		}
	}

	public void setId(String id) throws InvalidIdLengthException {
		if (id.length() < 3)
			throw new InvalidIdLengthException("Id length is less than 3");
		this.id = id;
	}
}
