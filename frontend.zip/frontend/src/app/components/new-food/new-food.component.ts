import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Food } from 'src/app/model/food';
import { FoodService } from 'src/app/service/food.service';

@Component({
  selector: 'app-new-food',
  templateUrl: './new-food.component.html',
  styleUrls: ['./new-food.component.css']
})
export class NewFoodComponent implements OnInit {

  food: Food = new Food();
  constructor(private foodService: FoodService,
    private router: Router) { }

  ngOnInit(): void {
  }

  save(): void {
    this.foodService.addNewFood(this.food)
      .subscribe(this.saveObserver);
  }

  saveObserver = {
    next: (resp: any) => {
      this.router.navigate(['/food-details', resp['id']]);
    }
  }

}
