import { Component, Input, OnInit } from '@angular/core';
import { Food } from 'src/app/model/food';
import { AuthService } from 'src/app/service/auth.service';

@Component({
  selector: 'app-food-card',
  templateUrl: './food-card.component.html',
  styleUrls: ['./food-card.component.css']
})
export class FoodCardComponent implements OnInit {

  @Input()
  food: Food = new Food();
  constructor(private authService: AuthService) { }

  ngOnInit(): void {
  }

  get isAdmin(): boolean {
    return this.authService.isAdmin();
  }

}
