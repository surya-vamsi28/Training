import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Food } from 'src/app/model/food';
import { AuthService } from 'src/app/service/auth.service';
import { FoodService } from 'src/app/service/food.service';

@Component({
  selector: 'app-food-details',
  templateUrl: './food-details.component.html',
  styleUrls: ['./food-details.component.css']
})
export class FoodDetailsComponent implements OnInit {

  food: Food = new Food();

  constructor(private activatedRoute: ActivatedRoute,
    private foodService: FoodService,
    private authService: AuthService,
    private router: Router) { }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(({ id }) => {
      this.foodService.getFood(id)
        .subscribe((food) => this.food = food as Food)
    })
  }

  get isAdmin(): boolean {
    return this.authService.isAdmin();
  }

  confirmAndDeleteFood(): void {
    if (confirm("Are you sure to delete this food item?")) {
      this.foodService.deleteFood(this.food.id || '')
        .subscribe(this.deleteObserver);
    }
  }

  deleteObserver = {
    next: () => {
      this.router.navigate(['/']);
    }
  };
}
