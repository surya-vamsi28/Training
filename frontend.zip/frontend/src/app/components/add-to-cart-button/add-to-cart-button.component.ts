import { Component, Input, OnInit } from '@angular/core';
import { Food } from 'src/app/model/food';
import { CartService } from 'src/app/service/cart.service';

@Component({
  selector: 'app-add-to-cart-button',
  templateUrl: './add-to-cart-button.component.html',
  styleUrls: ['./add-to-cart-button.component.css']
})
export class AddToCartButtonComponent implements OnInit {

  @Input()
  food: Food = new Food();

  constructor(private cartService: CartService) { }

  ngOnInit(): void {
  }

  addToCart() {
    this.cartService.addToCart(this.food)
  }

  decrementQuantity() {
    this.cartService.decrementQuantity(this.food);
  }

  get isInCart() {
    return this.cartService.isFoodInCart(this.food);
  }

  get quantity() {
    return this.cartService.getFoodQuantity(this.food);
  }
}
