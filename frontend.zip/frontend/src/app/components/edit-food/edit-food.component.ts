import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Food } from 'src/app/model/food';
import { FoodService } from 'src/app/service/food.service';

@Component({
  selector: 'app-edit-food',
  templateUrl: './edit-food.component.html',
  styleUrls: ['./edit-food.component.css']
})
export class EditFoodComponent implements OnInit {

  food: any = new Food();

  constructor(private foodService: FoodService,
    private activatedRoute: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(params => {
      let id = params['id'];
      this.foodService.getFood(id)
        .subscribe(data => this.food = data);
    });
  }

  save() {
    this.foodService.updateFood(this.food)
      .subscribe(this.saveObserver);
  }

  saveObserver = {
    next: (resp: any) => {
      this.router.navigate(['/food-details', resp['id']]);
    }
  }

}
