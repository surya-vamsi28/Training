import { Food } from "./food";

export class LineItem {
    food: Food = new Food();
    quantity: number = 0;
}
