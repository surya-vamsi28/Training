import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ordersUrl } from 'src/constants';
import { Order } from '../model/order';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  currentOrder: Order | undefined;

  constructor(private httpClient: HttpClient) { }

  placeOrder(order: Order): Observable<Order> {
    return this.httpClient.post(ordersUrl, order);
  }

  getOrderHistory(): Observable<any> {
    return this.httpClient.get(ordersUrl);
  }
}
