import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { cartUrl } from 'src/constants';

import { Food } from '../model/food';
import { LineItem } from '../model/line-item';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  cartItems: LineItem[] = [];

  constructor(private httpClient: HttpClient, private authService: AuthService) {

    let cart = sessionStorage.getItem('cart');
    if (cart) {
      this.cartItems = JSON.parse(cart);
    }

    this.authService.setSyncCart(this.syncCart.bind(this));
    this.syncCart();
  }

  syncCart() {
    console.log('just after login, sessionStorage.getItem(\'token\') is', sessionStorage.getItem('token'))
    if (sessionStorage.getItem('token')) {
      this.httpClient.get(cartUrl)
        .subscribe((resp: any) => {
          if (resp) {
            this.cartItems = resp['items'];
            sessionStorage.setItem('cart', JSON.stringify(this.cartItems));
          }
        });
    }
  }


  getCartItems() {
    return this.cartItems;
  }

  saveInSessionStorage() {
    sessionStorage.setItem('cart', JSON.stringify(this.cartItems));
    if (this.authService.isAuthenticated()) {
      this.httpClient.put(cartUrl, this.cartItems).subscribe();
    }
  }

  addToCart(food: Food) {
    let index = this.cartItems.findIndex((li: LineItem) => li.food.id === food.id);
    if (index === -1) {
      const item: LineItem = new LineItem();
      item.food = food;
      item.quantity = 1;
      this.cartItems.push(item);
    }
    else {
      const item = this.cartItems[index];
      item.quantity++;
    }
    this.saveInSessionStorage();
  }
  decrementQuantity(food: Food) {
    let index = this.cartItems.findIndex((li: LineItem) => li.food.id === food.id);
    if (index !== -1) {
      const item = this.cartItems[index];
      item.quantity--;
      if (item.quantity === 0) {
        this.cartItems.splice(index, 1);
      }
    }
    this.saveInSessionStorage();
  }

  deleteFromCart(food: Food) {
    let index = this.cartItems.findIndex((li: LineItem) => li.food.id === food.id);
    if (index !== -1) {
      this.cartItems.splice(index, 1);
      this.saveInSessionStorage();

    }
  }

  emptyCart() {
    this.cartItems = [];
    this.saveInSessionStorage();
  }

  isFoodInCart(food: Food) {
    let index = this.cartItems.findIndex((li: LineItem) => li.food.id === food.id);
    return index !== -1;
  }

  getFoodQuantity(food: Food) {
    let index = this.cartItems.findIndex((li: LineItem) => li.food.id === food.id);
    if (index === -1) {
      return 0;
    }
    else {
      return this.cartItems[index].quantity;
    }
  }

  isEmpty() {
    return this.cartItems.length === 0;
  }

  getCartSize() {
    return this.cartItems.length;
  }

  getCartTotal() {
    let total = 0;
    this.cartItems.forEach(li => { total += li.food.foodCost * li.quantity })
    return total;
  }
}
